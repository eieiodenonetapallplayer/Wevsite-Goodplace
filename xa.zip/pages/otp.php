<?php
$api_urls = [
    'disney' => 'https://byshop.me/api/otp_disney',
    'aisplay' => 'https://byshop.me/api/otp_aisplay',
    'trueid' => 'https://byshop.me/api/otp_trueid',
    'beinsports' => 'https://byshop.me/api/otp_beinsports',
];

foreach ($api_urls as $key => $api_url) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $api_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Cookie: PHPSESSID=u8df3d96ij8re36ld76cl64t3p'
        ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $load_packz = json_decode($response);
?>
<?php } ?>
<style>
    .modal-content {
        background: rgba(0, 0, 0, 0.025);
        backdrop-filter: blur(10px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
    }

    /* เพิ่มคลาส CSS เพื่อปรับภาพให้เป็นขาวดำ */
    .grayscale {
        filter: grayscale(100%);
        -webkit-filter: grayscale(100%);
    }
</style>
<!-- HTML สำหรับแสดงรูปภาพและตาราง -->
<div class="container-fluid mt-3 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-duotone fa-messages fa-xl" style="color: #ffffff;"></i> รับ OTP</h3>
        </div>
        <div class="row">
            <!-- DisneyPLUS -->
            <div class="col-12 col-lg-3 p-3" data-aos="zoom-in" data-aos="700">
                <a href="#" class="show-otp-modal" data-app-id="disney">
                    <img class="img-fluid border-glowing" src="https://media.discordapp.net/attachments/1170611526453956628/1171375089644736523/disneyplus_otp.png?ex=655c7310&is=6549fe10&hm=1006b895ddd9a5febe47cee6aae2116d1e5476cb076b5fde42ad7e42571e1d55&=&width=549&height=549">
                </a>
            </div>
            <!-- AISPLAY -->
            <div class="col-12 col-lg-3 p-3" data-aos="zoom-in" data-aos="700">
                <a href="#" class="show-otp-modal" data-app-id="aisplay">
                    <img class="img-fluid border-glowing" src="https://media.discordapp.net/attachments/1170611526453956628/1171375089883820063/aisplay_otp.png?ex=655c7310&is=6549fe10&hm=903b03ff30d9b244cf44d746d5e92ae87f5dc915ad82e064d5996d36e361ff65&=&width=549&height=549">
                </a>
            </div>
            <!-- TRUEID -->
            <div class="col-12 col-lg-3 p-3" data-aos="zoom-in" data-aos="700">
                <a href="#" class="show-otp-modal" data-app-id="trueid">
                    <img class="img-fluid border-glowing" src="https://media.discordapp.net/attachments/1170611526453956628/1171376655055458314/trueidplus_otp.png?ex=655c7485&is=6549ff85&hm=a008aac2eb579f0f852b6a63c2b1d48b180a3ae7fd2a19d8995a27b7fae28138&=&width=549&height=549">
                </a>
            </div>
            <!-- BEINSPORTS -->
            <div class="col-12 col-lg-3 p-3" data-aos="zoom-in" data-aos="700">
                <a href="#" class="show-otp-modal" data-app-id="beinsports">
                    <img class="img-fluid border-glowing" src="https://media.discordapp.net/attachments/1170611526453956628/1171376655344881685/beinsport_otp.png?ex=655c7485&is=6549ff85&hm=6c731f752fdd66a1295c67cb17d124bb1514353490127be99aa86f2f036edd31&=&width=549&height=549">
                </a>
            </div>
        </div>
    </div>
</div>
<!-- โมเดลเพื่อแสดงข้อมูล OTP -->
<div class="modal fade" id="otpModal" tabindex="-1" aria-labelledby="otpModalLabel" aria-hidden="true">
    <div class="modal-dialog"> <!--- modal-dialog-centered --->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="otpModalLabel">ข้อมูล OTP</h5>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" aria-label="ปิด">ปิด</button>
            </div>
            <div class="modal-body">
                <div id="otpData"></div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        var apiUrls = <?php echo json_encode($api_urls); ?>;

        // เมื่อคลิกที่ลิงก์
        $('.show-otp-modal').click(function() {
            var modalId = 'otpModal';
            // ดึงค่า data-app-id จากลิงก์
            var appId = $(this).data('app-id');
            // ดึงข้อมูล OTP จาก API โดยใช้ URL ที่เกี่ยวข้องกับแอพนั้น ๆ
            var apiUrl = apiUrls[appId];

            $.ajax({
                url: apiUrl,
                type: 'GET',
                dataType: 'json',
                success: function(data) {
                    var modal = $('#' + modalId);
                    var modalTitle = modal.find('.modal-title');
                    var modalBody = modal.find('.modal-body');
                    var otpData = '';

                    // แสดงเพียง 3 รายการล่าสุด
                    var maxItems = 3;
                    for (var i = 0; i < Math.min(maxItems, data.length); i++) {
                        var otp = data[i];
                        otpData += '<p>' + otp.sms + '</p>';
                        otpData += '<p>' + otp.messenger + '</p>';
                        otpData += '<p><span class="badge text-bg-danger" style="font-size:15px">เวลาส่ง : ' + otp.time + '</span></p>';
                        otpData += '<hr>';
                    }

                    modalTitle.text('กล่องข้อความ');
                    modalBody.find('#otpData').html(otpData);
                    modal.modal('show');
                }
            });
        });
    });
</script>