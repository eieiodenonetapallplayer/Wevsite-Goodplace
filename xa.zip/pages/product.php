<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
$product_self = $thxk->product($_GET['type']);
?>
<style>
    .modal-content {
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(5px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
        box-shadow: 2px rgba(11, 11, 11, 0.3);
    }
</style>

<div class="container-fluid mt-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4><i class="fa-duotone fa-layer-group"></i> หมวดหมู่ <?= $product_self[0]['type']; ?></h4>
            <a href="/shoping" class="btn btn-thxk">ย้อนกลับ</a>
        </div>
        <div class="row">
            <?php foreach ($product_self as $product) {
                $totalproduct = $thxk->totalproduct($product['id']);  ?>
                <div class="col-6 col-lg-3 p-3" data-aos="zoom-in">
                    <div class="card-body border-glowing p-3" style="border-radius:1vh;">
                        <?php
                        $imgClasses = 'img-fluid';
                        ?>
                        <img class="<?= $imgClasses ?>" style="border-radius:1vh;" src="<?= $product['image_product']; ?>" alt="<?= $product['name_product']; ?>">
                        <hr style="color:#999;">
                        <div class="p-2">
                            <p style="font-size:17px;"><?php echo $product['name_product']; ?></p>
                            <p style="font-size:16px;">ราคา&nbsp;<?php echo $product['price_product']; ?>฿</p>
                            <p style="font-size:16px;">สินค้าคงเหลือ&nbsp;<?php echo $totalproduct['total']; ?>&nbsp;รายการ</p>
                            <button class="btn btn-danger py-2 w-100" data-bs-toggle="modal" data-bs-target="#productModal<?= $product['id']; ?>" data-id="<?= $product['id']; ?>"><i class="fa-duotone fa-bag-shopping"></i>&nbsp;สั่งซื้อสินค้า</button>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php foreach ($product_self as $product) { ?>
    <div class="modal fade" id="productModal<?= $product['id']; ?>" tabindex="-1" aria-labelledby="productModalLabel<?= $product['id']; ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <?php
                            $imgClasses = 'img-fluid';
                            ?>
                            <img class="mb-2 <?= $imgClasses ?>" style="border-radius:2vh;" src="<?= $product['image_product']; ?>" alt="<?= $product['name_product']; ?>">
                        </div>
                        <div class="col-12 col-lg-6">
                            <h5><?= $product['name_product']; ?></h5>
                            <hr>
                            <p><?= $product['details_product']; ?></p>
                        </div>
                        <div class="row p-2 align-items-center text-center">
                            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                <a class="neon-button w-100" data-bs-dismiss="modal">ยกเลิก</a>
                            </div>
                            <div class="col-12 col-lg-6">
                                <a class="submit_buyproduct neon-button w-100" data-product-id="<?php echo $product['id']; ?>" data-product-name="<?php echo $product['name_product']; ?>" data-product-price="<?php echo $product['price_product']; ?>">
                                    ซื้อสินค้า <?php echo $product['price_product']; ?>฿
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<script src="/js/buyproduct_stock.js"></script>