<?php
$thxk = new member;
$webconfig = $thxk->webconfig();
$contact = $thxk->contact();
?>
<footer>
    <div class="bg-nav p-3 mt-3">
        <div class="container">
            <center>
                <div class="row">
                    <div class="col-12 col-md-4 mt-3 mb-3">
                        <img class="img-fluid" src="<?= $webconfig['logo_icon'] ?>" width="180px">
                        <p class="mt-3"><?= $webconfig['description'] ?></p>
                    </div>
                    <div class="col-12 col-md-4 mb-3">
                        <h4 style="font-size: 20px;">เมนูช่วยเหลือ</h4>
                        <hr style="color: white;">
                        <a style="font-size: 15px;" href="/home">
                            <p><i class="fa-duotone fa-house fa-beat"></i> หน้าหลัก</p>
                        </a>
                        <a style="font-size: 15px;" href="/shoping">
                            <p><i class="fa-duotone fa-cart-shopping fa-beat"></i> ร้านค้า</p>
                        </a>
                        <a style="font-size: 15px;" href="/app">
                            <p><i class="fa-duotone fa-signal-stream fa-beat"></i> แอพสตรีมมิ่ง</p>
                        </a>
                        <a style="font-size: 15px;" href="/topup">
                            <p><i class="fa-solid fa-money-check-dollar-pen fa-beat"></i> เติมเงิน</p>
                        </a>
                        <a style="font-size: 15px;" href="/history_buyproduct">
                            <p><i class="fa-duotone fa-list fa-beat"></i> ประวัติการซื้อ</p>
                        </a>
                        <a style="font-size: 15px;" href="/profile">
                            <p><i class="fa-duotone fa-gear fa-beat"></i> ตั้งค่าบัญชี</p>
                        </a>
                        <a style="font-size: 15px;" href="<?php echo $contact['line'] ?>">
                            <p><i class="fa-brands fa-facebook fa-beat"></i> ติดต่อเพจ</p>
                        </a>
                    </div>
                    <div class="col-12 col-md-4 mb-3">
                        <h4 style="font-size: 20px;">ช่องการติดต่อ</h4>
                        <hr style="color: white;">
                        <iframe src="https://discord.com/widget?id=<?php echo $contact['discord'] ?>&theme=dark" width="350" height="350" allowtransparency="true" frameborder="0" sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>
                    </div>
                </div>
            </center>
        </div>
    </div>
</footer>