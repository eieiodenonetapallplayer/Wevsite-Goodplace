<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
$history_w = $thxk->history_wallet();
$history_verifyslip = $thxk->history_verifyslip();
?>
<div class="container-fluid mt-3 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-regular fa-wallet fa-xl" style="color: #ffffff;"></i> ช่องทางการเติมเงิน</h3>
        </div>
        <div class="row mb-4" data-aos="zoom-in" data-aos="700">
            <div class="col-12 col-lg-4 p-3">
                <a href="/topup/wallet">
                    <img class="product-image img-fluid border-glowing img-product" src="https://kyoji.org/assets/tw5.png">
                </a>
            </div>
            <div class="col-12 col-lg-4 p-3">
                <a href="/topup/bank">
                    <img class="product-image img-fluid border-glowing img-product" src="https://kyoji.org/assets/vs5.png">
                </a>
            </div>
        </div>
        <ul class="nav nav-tabs" id="myTab" role="tablist" data-aos="zoom-in" data-aos="700">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="truewallet-tab" data-toggle="tab" href="#truewallet" role="tab" aria-controls="truewallet" aria-selected="true">ประวัติการเติมเงิน Truewallet</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="verifyslip-tab" data-toggle="tab" href="#verifyslip" role="tab" aria-controls="verifyslip" aria-selected="false">ประวัติการเติมเงิน ธนาคาร (Verify Slip)</a>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent" data-aos="zoom-in" data-aos="700">
            <div class="tab-pane fade show active" id="truewallet" role="tabpanel" aria-labelledby="truewallet-tab">
                <div class="class-thxk p-4 mt-2 mb-3">
                    <h5>ประวัติการเติมเงิน TrueWallet 5 รายการล่าสุด</h5>
                    <hr>
                    <div class="table-responsive">
                        <table id="truewalletTable" class="table table-striped table-dark text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>ชื่อบัญชี</th>
                                    <th>จำนวน</th>
                                    <th>ค่าธรรมเนียม</th>
                                    <th>สถานะ</th>
                                    <th>เวลาทำรายการ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // เรียงลำดับประวัติ Truewallet จากล่าสุดไปยังเก่า
                                $history_w = array_reverse($history_w);

                                $count = 0;
                                foreach ($history_w as $history_wallet) {
                                    if ($resultuser['username'] === $history_wallet['username'] && $count < 5) {
                                        $count++;
                                ?>
                                        <tr>
                                            <td><?= $history_wallet['id']; ?></td>
                                            <td><?= $history_wallet['name']; ?></td>
                                            <td><?= $history_wallet['amount']; ?></td>
                                            <td><span class="badge text-bg-danger" style="font-size:15px"> 0%</span></td>
                                            <td><span class="badge text-bg-success" style="font-size:15px"><i class="fa-sharp fa-regular fa-circle-check"></i> สำเร็จ</span></td>
                                            <td><?= $history_wallet['date']; ?></td>
                                        </tr>
                                    <?php } ?>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="verifyslip" role="tabpanel" aria-labelledby="verifyslip-tab">
                <div class="class-thxk p-4 mt-2 mb-3">
                    <h5>ประวัติการเติมเงิน ธนาคาร (Verify Slip) 5 รายการล่าสุด</h5>
                    <hr>
                    <table id="verifyslipTable" class="table table-striped table-dark text-center" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>ชื่อบัญชี</th>
                                <th>จำนวนเงิน</th>
                                <th>ค่าธรรมเนียม</th>
                                <th>สถานะ</th>
                                <th>เวลาทำรายการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // เรียงลำดับประวัติ Verify Slip จากล่าสุดไปยังเก่า
                            $history_verifyslip = array_reverse($history_verifyslip);

                            $count = 0;
                            foreach ($history_verifyslip as $history_slip) {
                                if ($resultuser['username'] === $history_slip['username'] && $count < 5) {
                                    $count++;
                            ?>
                                    <tr>
                                        <td><?= $history_slip['id']; ?></td>
                                        <td><?= $history_slip['customer_name']; ?></td>
                                        <td><?= $history_slip['amount']; ?></td>
                                        <td><span class="badge text-bg-danger" style="font-size:15px"> 0%</span></td>
                                        <td><span class="badge text-bg-success" style="font-size:15px"><i class="fa-sharp fa-regular fa-circle-check"></i> สำเร็จ</span></td>
                                        <td><?= $history_slip['date']; ?></td>
                                    </tr>
                                <?php } ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                $('#myTab a').on('click', function(e) {
                    e.preventDefault();
                    $(this).tab('show');
                });
            });
        </script>
    </div>
</div>