<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
?>
<div class="container-fluid mt-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4">
            <div class="text-center">
                <h3><i class="fa-solid fa-address-card fa-lg" style="color: #ffffff;"></i> ตั้งค่าบัญชีของคุณ</h3>
                <hr>
            </div>
            <div class="row">
                <div class="col-md-6 mb-5">
                    <div class="container-fluid class-menu p-4 pt-5 rounded shadow-sm border-ys count-only" style="border-radius: 1vh;">
                        <div style="text-decoration: none;">
                            <center>
                                <h3><i class="fa-solid fa-address-card fa-lg" style="color: #ffffff;"></i> ข้อมูลส่วนตัว</h3>
                                <hr>
                                <p class="ms-1 mb-2"> Username (ชื่อผู้ใช้) </p>
                                <div class="input-group mb-2">
                                    <input type="text" class="form-control text-center mx-auto d-block" style="font-weight:bold;" value="<?php echo $resultuser['username']; ?>" disabled>
                                </div>
                                <p class="ms-1 mb-2"> Email (อีเมล) </p>
                                <div class="input-group mb-2">
                                    <input type="text" class="form-control text-center mx-auto d-block" style="font-weight:bold;" value="<?php echo $resultuser['email']; ?>" disabled>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="ms-1 mb-2"> ยอดเงินคงเหลือ </p>
                                        <div class="input-group mb-2">
                                            <input type="text" class="form-control text-center mx-auto d-block" style="font-weight:bold;" value="<?php echo $resultuser['point']; ?> บาท" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="ms-1 mb-2"> ยอดเติมเงินรวม </p>
                                        <div class="input-group mb-2">
                                            <input type="text" class="form-control text-center mx-auto d-block" style="font-weight:bold;" value="<?php echo $resultuser['topup']; ?> บาท" disabled>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="ms-1 mb-2">ระดับสมาชิก</p>
                                        <div class="input-group mb-2">
                                            <input type="text" class="form-control text-center mx-auto d-block" style="font-weight: bold;" value="<?php echo ($resultuser['rank'] == 1) ? 'แอดมินดูแลระบบ' : 'สมาชิกทั่วไป'; ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <p class="ms-1 mb-2"> สมัครสมาชิกเมื่อ </p>
                                        <div class="input-group mb-2">
                                            <input type="text" class="form-control text-center mx-auto d-block" style="font-weight:bold;" value="<?php echo $resultuser['date']; ?>" disabled>
                                        </div>
                                    </div>
                            </center>
                        </div>
                    </div>
                </div>
                <!-- คอลัม์สอง -->
                <div class="col-md-6 mb-5">
                    <div class="container-fluid class-menu p-4 pt-5 rounded shadow-sm border-ys count-only" style="border-radius: 1vh;">
                        <div style="text-decoration: none;">
                            <center>
                                <h3><i class="fa-duotone fa-lock fa-lg"></i> เปลี่ยนรหัสผ่าน</h3>
                                <hr>
                                <p class="ms-1 mb-2">รหัสผ่านเก่า</p>
                                <div class="input-group mb-2">
                                    <input type="password" id="password_old" class="form-control text-center mx-auto d-block" style="font-weight: bold;">
                                </div>
                                <p class="ms-1 mb-2">รหัสผ่านใหม่</p>
                                <div class="input-group mb-2">
                                    <input type="password" id="password_new" class="form-control text-center mx-auto d-block" style="font-weight: bold;">
                                </div>
                                <p class="ms-1 mb-2">ยืนยันรหัสผ่านใหม่</p>
                                <div class="input-group mb-2">
                                    <input type="password" id="password_new_confirm" class="form-control text-center mx-auto d-block" style="font-weight: bold;">
                                </div>
                                <p class="ms-1 mb-2"><span style="color:#33FF00;">รหัสผ่านที่ดี</span> คือ รหัสผ่านที่มีอักษร<span style="color:red;">ตัวพิมพ์เล็ก</span>และ<span style="color:red;">ตัวพิมพ์ใหญ่</span>ผสมกัน</p>
                                <button class="btn btn-danger w-100 mb-2" type="button" id="submit_password">เปลี่ยนรหัสผ่าน</button>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/js/password.js"></script>