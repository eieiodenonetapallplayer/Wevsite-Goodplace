<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
$thxk->product_apibyshop();
$webconfig = $thxk->webconfig();
$products = $thxk->products_byshopme();
$byshopme = $thxk->byshopme_api();

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api_app_premium.byshop.me/api/history',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 1,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => array('keyapi' => $byshopme['apikey_byshopme']),
    CURLOPT_HTTPHEADER => array(
        'Cookie: PHPSESSID=u8df3d96ij8re36ld76cl64t3p'
    ),
));
$response = curl_exec($curl);
$listbuy = json_decode($response);
curl_close($curl);

?>
<style>
    .modal-content {
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(5px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
        box-shadow: 2px rgba(11, 11, 11, 0.3);
    }

    .grayscale {
        filter: grayscale(100%);
        -webkit-filter: grayscale(100%);
    }

    a {
        text-decoration: none;
    }
</style>
<div class="container-fluid mt-4 p-0" data-aos="fade-top">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-2 mb-3">
            <marquee direction="left">
                <div class="d-flex flex-row p-2">
                    <?php
                    $product_list_buy = '';

                    if (empty($byshopme['apikey_byshopme'])) {
                        $product_list_buy = '<div style="color: #ffffff; font-size: 110%">คีย์ API ไม่ถูกต้อง กรุณาอัปเดต API ก่อน</div>';
                    } else {
                        foreach ($listbuy as $item) {
                            if (strpos($item->name, 'TEST API') === false) {
                                $product_list_buy .= '<div style="color: #ffffff; font-size: 80%" class="d-flex mr-5 mt-3"> <br>  
                                <img class="img-fluid rounded" style="margin:0 auto; height: 50px;" src="https://img_app.byshop.me/buy/img/img_app/' . substr($item->name, 0, 2) . '.png">
                                <span><b>&nbsp;&nbsp;&nbsp;' . $item->name . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
                                <br>&nbsp;&nbsp;&nbsp;' . $item->time . '
                                <b><p style="font-size: 13px">&nbsp;&nbsp;<span class="rounded-pill badge bg-success">&nbsp;&nbsp;<i class="fa fa-check-circle" aria-hidden="true"></i> ขายแล้ว !! &nbsp;&nbsp;</span></b><br></p>
                            </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                            }
                        }
                    }
                    if (empty($product_list_buy)) {
                        $product_list_buy = "<div class='text-white'><img src='assets/ann.png' style='margin: 0 auto; height: 30px;'> ไม่มีประวัติการซื้อสินค้าแอพสตรีมมิ่ง</div>";
                    }
                    echo $product_list_buy;
                    ?>
                </div>
            </marquee>
        </div>
    </div>
</div>
<div class="container-fluid mt-2 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mt-3"><i class="fa-duotone fa-cart-shopping-fast"></i> แอพสตรีมมิ่ง</h4>
            <a href="/home" class="btn btn-thxk">ย้อนกลับ</a>
        </div>
        <div class="row">
            <?php foreach ($products as $product) { ?>
                <?php if ($product['product_status'] === 'on') { ?>
                    <div class="col-6 col-lg-3 mt-3 mb-3" data-aos="zoom-in">
                        <?php
                        $imgClasses = 'img-fluid border-glowing';
                        if ($product['api_stock'] == 0) {
                            $imgClasses .= ' grayscale'; // ใส่คลาส CSS "grayscale" ถ้า stock เป็น 0
                        }
                        ?>
                        <img class="<?= $imgClasses ?>" style="border-radius:2vh" data-bs-toggle="modal" data-bs-target="#productModal-<?= $product['product_code']; ?>" data-id="<?= $product['product_code']; ?>" src="<?= $product['product_image']; ?>" alt="<?= $product['product_name']; ?>">
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
</div>
<?php foreach ($products as $product) { ?>
    <?php if ($product['product_status'] === 'on') { ?>
        <div class="modal fade" id="productModal-<?= $product['product_code']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <?php
                                $imgClasses = 'img-fluid';
                                if ($product['api_stock'] == 0) {
                                    $imgClasses .= ' grayscale';
                                }
                                ?>
                                <div class="text-center" style="position: relative;">
                                    <img class="<?= $imgClasses ?>" style="border-radius:2vh" src="<?php echo $product['product_image']; ?>" alt="<?= $product['product_name']; ?>">
                                    <?php if ($product['api_status'] == 'สินค้าหมด') { ?>
                                        <div style="position: absolute; top: 10%; left: 50%; transform: translate(-50%, -50%); 
        font-size: 20px; background: rgba(255, 0, 0, 0.5); padding: 10px; width:300px; border-radius: 5px;">
                                            สินค้าจำหน่ายหมดแล้ว
                                        </div>
                                    <?php } elseif ($product['api_status'] == 'พร้อมส่ง') { ?>
                                        <div style="position: absolute; top: 10%; left: 50%; transform: translate(-50%, -50%); 
        font-size: 20px; background: rgba(0, 255, 0, 0.5); padding: 10px; width:300px; border-radius: 5px;">
                                            สินค้าพร้อมจำหน่าย
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <p><?php echo $product['product_info']; ?></p>
                                <div class="row">
                                    <div class="col-12 col-lg-6">
                                        <p>สินค้าคงเหลือ : <?php echo $product['api_stock']; ?> ชิ้น</p>
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <p>สถานะ : <?php echo $product['api_status']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row p-2 align-items-center text-center">
                            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                <a class="neon-button w-100" data-bs-dismiss="modal">ยกเลิก</a>
                            </div>
                            <div class="col-12 col-lg-6">
                                <?php if ($product['api_status'] == 'สินค้าหมด') { ?>
                                    <a class="neon-button w-100">❌ สินค้าหมด ❌</a>
                                <?php } elseif ($product['api_status'] == 'พร้อมจำหน่าย') { ?>
                                    <a class="buyproduct-btn neon-button w-100" data-product-id="<?php echo $product['product_code']; ?>" data-product-name="<?php echo $product['product_name']; ?>" data-product-price="<?php echo $product['product_sell']; ?>">ซื้อสินค้า <?php echo $product['product_sell']; ?>฿ </a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
<script src="/js/buyproduct.js"></script>