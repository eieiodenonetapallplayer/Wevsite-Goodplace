
<div class="container-sm">
    <div class="row">
        <div class="col-lg-4 mt-4">
            <div class="class-thxk">
                <div class="p-3">
                    <?php
                        $result_load_packz = dd_q("SELECT * FROM category_topupgame WHERE id = '12'");
                        if ($row = $result_load_packz->fetch(PDO::FETCH_ASSOC)) :
                    ?>
                    <center>
                        <img src="<?php echo $row['img']; ?>" style="width: 80%;border-radius: 1vh;" >
                        <h5 class="mt-4"><?php echo $row['name']; ?></h5>
                        <hr style="color: #ffffff;">
                        <small class="mt-4"><?php echo $row['des']; ?></small>
                    </center>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-8 mt-4">
            <div class="class-thxk p-3">
                <form class="row g-3" method="post">
                    <div class="card-header text-white">
                        <?php
                            $result_load_packz = dd_q("SELECT * FROM category_topupgame WHERE id = '12'");
                            if ($row = $result_load_packz->fetch(PDO::FETCH_ASSOC)) :
                        ?>
                        <img src="<?php echo $row['img']; ?>" width="30" class="mb-1"> เติมเกมออนไลน์ <?php echo $row['name']; ?>
                        <?php endif; ?>
                    </div>
                    <div class="alert alert-danger text-center mt-3 mb-0 h6" role="alert">
                        <i class="fas fa-exclamation-circle"></i> หลังจากทำรายไม่สามารถยกเลิกหรือขอคืนเงินได้ <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="col-sm-6 col-lg-12">
                        <label for="user" class="form-label text-white"><i class="fa-solid fa-circle-user"></i> กรอก UID หรือ ID game </label>
                        <input type="text" class="form-control" id="uid" placeholder="ID เกมของคุณ" required>
                    </div>
                    <div class="col-sm-6 col-lg-12">
                        <label for="Mobilecompany" class="form-label text-white"><i class="fa-solid fa-gem"></i> เลือกรายการเติม</label>
                        <select class="form-select" id="mobilecompany" required>
                            <option value="0">เลือกรายการ</option>
                            <?php
                            $result_load_packz = dd_q("SELECT * FROM ragnarok WHERE status = 'เปิดขาย'");
                            while ($row = $result_load_packz->fetch(PDO::FETCH_ASSOC)) {
                                $name = $row['name'];
                                $amount = $row['amount'];
                                echo "<option value=\"$amount\">$name - $amount บาท</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-sm-6 col-lg-12">
                        <label for="quantity" class="form-label text-white"><i class="fa-solid fa-coins"></i> จำนวนเงินที่ต้องจ่าย</label>
                        <div class="input-group"></div>
                        <input type="text" class="form-control" disabled placeholder="amount" id="amount" value="0 บาท">
                    </div>             
                    <br>
                    <div class="col-12">
                        <button type="submit" class="btn btn-neon w-100" id="btn_regis">ยืนยันการเติม</button>
                        <div class="col-md-12 text-white mb-4 mt-2">
                            <hr>
                            - <span style="color: rgb(224, 62, 45);"><strong>กรุณาใส่เลข ID ให้ถูกต้อง</strong></span> หากลูกค้ากรอกเลข ID มาผิด</strong></span> ทางเราจะไม่รับผิดชอบและไม่มีการคืนเงินใด ๆ ทั้งสิ้น<br>
                            - หลังจากสั่งซื้อสำเร็จ จะขึ้นสถานะคำสั่งซื้อว่า รอดำเนินการ และ สำเร็จ ตามลำดับ กรุณารอ 1 - 15 นาที<br>
                            - <strong><span style="color: rgb(224, 62, 45);">ไม่มีการยกเลิกรายการ</span></strong> และไม่สามารถขอคืนเงินหรือเครดิตได้ หลังการทำรายการแล้ว<br>
                            - หากมีข้อสงสัยหรือเกิดปัญหา ให้แจ้งทางเจ้าหน้าที่ของเราผ่านช่องทางติดต่อบนหน้าเว็บไซต์ได้ทุกช่องทาง
                        </div>
                    </div>
                </form>
                <br>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $("#btn_regis").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('userid', $("#uid").val());
        $('#btn_regis').attr('disabled', 'disabled');

        var selectedName = $('#mobilecompany').find(":selected").text().split(' - ')[0];
        var idMapping = {
            '40 Nyan': "1",
            '125 Nyan': "2",
            '210 Nyan': "3",
            '430 Nyan': "4",
            '900 Nyan': "5",
            '2,300 Nyan': "6"
        };

        if (idMapping.hasOwnProperty(selectedName)) {
            formData.append('id', idMapping[selectedName]);
        } else {
            Swal.fire({
                icon: 'error',
                title: 'ผิดพลาด',
                text: 'กรุณาเลือกรายการ'
            });
            $('#btn_regis').removeAttr('disabled');
            return;
        }

        $.ajax({
            type: 'POST',
            url: '../systems/topupgame/ragnarok.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            result = res;
            console.log(result);

            if (res.status == "success") {
                Swal.fire({
                    icon: 'success',
                    title: 'สำเร็จ',
                    text: result.message
                }).then(function () {
                    window.location = "#";
                });
            }

            if (res.status == "fail") {
                Swal.fire({
                    icon: 'error',
                    title: 'ผิดพลาด',
                    text: result.message
                });
                $('#btn_regis').removeAttr('disabled');
            }
        }).fail(function (jqXHR) {
            console.log(jqXHR);
            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: res.message
            });
            $('#btn_regis').removeAttr('disabled');
        });
    });
</script>

<script>
    $(document).ready(function () {
        $('#mobilecompany').change(function () {
            var selectedOption = $(this).find(":selected");
            var selectedAmount = selectedOption.val();
            $('#amount').val(selectedAmount + ' บาท');
        });
    });
</script>