<?php
$thxk = new member;
$cate_topupgames = $thxk->cate_topupgames();
?>
<div class="container-fluid mt-2 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mt-3"><i class="fa-duotone fa-gamepad-modern"></i> เติมเกมออนไลน์</h4>
            <a href="/home" class="btn btn-thxk">ย้อนกลับ</a>
        </div>
        <div class="row">
            <?php foreach ($cate_topupgames as $cate) { ?>
                <div class="col-6 col-lg-3 mt-3 mb-3" data-aos="zoom-in">
                    <a href="/topupgame<?php echo $cate['link']; ?>">
                        <img class="img-fluid border-glowing" style="border-radius:2vh" src="<?php echo $cate['img']; ?>" alt="<?php echo $cate['name']; ?>">
                    </a>
                </div>
            <?php } ?>

        </div>
    </div>
</div>