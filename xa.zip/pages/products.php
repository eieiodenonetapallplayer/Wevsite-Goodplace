<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
$webconfig = $thxk->webconfig();
$product_self = $thxk->card_product();
$category = $thxk->show_category();
?>
<style>
    .modal-content {
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(5px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
        box-shadow: 2px rgba(11, 11, 11, 0.3);
    }
</style>
<div class="container-fluid mt-4 p-0" data-aos="zoom-in">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-2">
            <marquee direction="left">
                <div class="d-flex flex-row ">
                    <?php
                    $thxk = new member;
                    $history_buy = $thxk->history_buy();
                    ?>
                    <div style="color: #ffffff; font-size: 90%" class="d-flex mr-5 mt-3"> <br>
                        <?php if (empty($history_buy)) { ?>
                            <img class="img-fluid rounded" style="margin: 0 auto; height: 30px;" src="assets/ann.png">
                            <p>ประกาศ : ยังไม่มีประวัติการซื้อสินค้า 💕</p>
                        <?php } else { ?>
                            <div class="d-flex flex-row ">
                                <?php foreach ($history_buy as $history) { ?>
                                    <img class="img-fluid rounded" style="margin: 0 auto; height: 30px;" src="assets/ann.png">
                                    <span><b>&nbsp;&nbsp;&nbsp; <?php echo $history['name']; ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
                                        <br>&nbsp;&nbsp;&nbsp; <?php echo $history['date']; ?>
                                        <b>
                                            <p style="font-size: 13px">&nbsp;&nbsp;<span class="rounded-pill badge bg-success">&nbsp;&nbsp;<i class="fa fa-check-circle" aria-hidden="true"></i> ขายสินค้าเรียบร้อยแล้ว !! &nbsp;&nbsp;</span>
                                        </b><br></p>
                                    </span>
                                <?php } ?>
                            </div>
                        <?php } ?>
                    </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </div>
            </marquee>
        </div>
    </div>
</div>
<div class="container-fluid mt-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4><i class="fa-duotone fa-layer-group"></i> หมวดหมู่สินค้า</h4>
            <a href="/home" class="btn btn-thxk">ย้อนกลับ</a>
        </div>
        <div class="row">
            <?php foreach ($category as $category) { ?>
                <div class="col-12 col-md-6 col-sm-12 mb-3" data-aos="zoom-in">
                    <a href="/product?type=<?php echo $category['name'] ?>">
                        <img src="<?php echo $category['img']; ?>" style="border-radius:2vh;" class="border-glowing img-fluid">
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</div>