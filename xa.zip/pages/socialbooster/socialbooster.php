<div class="container-sm">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="bg-navvx p-2 mt-4">
                <div class="p-2">
                    <h4><b><center>เลือกบริการที่ต้องการ</center></b></h4>
                    <br>
                    <label for="category" class="text-white">หมวดหมู่ <span class="text-red">*</span></label>
                    <select class="form-select mt-1" name="category" id="category">
                        <option value="19">รวมโปรโมชั่นพิเศษวันนี้</option>
                        <option value="19">All-Social 🆕</option>
                    </select>
                    <br>
                    <label for="services" class="text-white">บริการที่ต้องการ <span class="text-red">*</span></label>
                    <select class="form-select mt-1" name="services" id="services"></select>
                    <br>
                    <div class="form-group">
                        <label for="serviceDetails" class="text-white">รายละเอียดบริการ</label>
                        <textarea class="form-control mt-1" id="serviceDetails" rows="3" disabled></textarea>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="link" class="text-white">ลิ้งค์ <span class="text-red">*</span></label>
                        <input type="text" name="link" id="link" class="form-control mt-1" placeholder="ลิ้งค์" required />
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="squantity" class="text-white">จำนวน <span class="text-red">*</span></label>
                        <input type="number" name="squantity" id="squantity" class="form-control mt-1" placeholder="จำนวน" required />
                    </div>
                    <span class="badge bg-danger" id="minOrder">ขั้นต่ำ: 10-1000</span>
                    <span class="badge bg-success" id="maxOrder">สูงสุด: 400000</span>
                    <br>
                    <div class="form-group">
                        <label for="charge" class="text-white">อัตราค่าบริการ <span class="text-red">*</span></label>
                        <input type="text" name="charge" id="charge" class="form-control mt-1" placeholder="อัตราค่าบริการ" disabled />
                    </div>
                    <br>
                    <div class="d-grid gap-2">
                        <button class="btn btn-success" id="social-booster" disabled>ทำรายการ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $("#social-booster").click(function () {
        var formData = new FormData();

        var selectedService = document.getElementById('services').value;
        var match = selectedService.match(/ID (\d+)/);
        var selectedServiceId = match ? match[1] : null;

        formData.append('id', selectedServiceId);
        formData.append('link', $("#link").val());
        formData.append('squantity', $("#squantity").val());

        $.ajax({
            type: 'POST',
            url: '../systems/socialbooster/socialbooster.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            result = res;

            if (result.status == "success") {
                Swal.fire({
                    icon: 'success',
                    title: 'สำเร็จ',
                    text: result.message
                }).then(function () {
                    window.location = "?page=socialbooster";
                });
            }

            if (result.status == "fail") {
                Swal.fire({
                    icon: 'error',
                    title: 'ผิดพลาด',
                    text: result.message
                });
                $('#social-booster').removeAttr('disabled');
            }
        }).fail(function (jqXHR) {
            console.log(jqXHR);
            res = jqXHR.responseJSON;

            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: res.message
            });
            $('#social-booster').removeAttr('disabled');
        });
    });

    function calculateTotalCharge() {
        var selectedService = document.getElementById('services').value;
        var selectedServiceName = document.getElementById('services').options[document.getElementById('services').selectedIndex].text;

        var priceRegex = /(\d+\.\d{2}) บาท$/;
        var match = selectedServiceName.match(priceRegex);

        if (match) {
            var extractedPrice = parseFloat(match[1]) / 1000;

            var quantity = parseFloat(document.getElementById('squantity').value);

            if (!isNaN(quantity) && quantity > 0) {
                var totalPrice = extractedPrice * quantity;
                document.getElementById('charge').value = 'ราคารวม: ' + totalPrice.toFixed(2) + ' บาท';
            } else {
                document.getElementById('charge').value = 'กรุณาใส่จำนวนที่ถูกต้อง';
            }
        } else {
            document.getElementById('charge').value = 'ไม่สามารถสกัดราคาได้';
        }
    }

    document.getElementById('services').addEventListener('change', calculateTotalCharge);
    document.getElementById('squantity').addEventListener('input', calculateTotalCharge);

    document.getElementById('services').addEventListener('change', function () {
        calculateTotalCharge();

        var selectedOption = this.options[this.selectedIndex];
        var serviceDetails = selectedOption.getAttribute('data-description');
        document.getElementById('serviceDetails').value = serviceDetails ? serviceDetails : 'ไม่พบรายละเอียด';
    });

    $(document).ready(function () {
        <?php
        $result_load_packz = dd_q("SELECT * FROM socialservice");
        $servicesFromDatabase = [];
        while ($row = $result_load_packz->fetch(PDO::FETCH_ASSOC)) {
            $serviceOption = "- ID {$row['id']} {$row['name']} {$row['price']} บาท";
            $serviceDescription = $row['des'];
            $servicesFromDatabase[] = ['option' => $serviceOption, 'description' => $serviceDescription];
        }
        ?>
        var categoryServices = {
            "19": ["รวมโปรโมชั่นพิเศษวันนี้"],
            "19": <?php echo json_encode($servicesFromDatabase); ?>
        };

        $("#category").change(function () {
            var selectedCategory = $(this).val();
            var services = categoryServices[selectedCategory] || [];

            $("#services").empty();
            $.each(services, function (index, service) {
                var option = $('<option>', {
                    value: service.option,
                    text: service.option.split(' ').slice(3).join(' '),
                    'data-description': service.description
                });
                $("#services").append(option);
            });

            $("#social-booster").prop("disabled", services.length === 0);
        });
    });
</script>