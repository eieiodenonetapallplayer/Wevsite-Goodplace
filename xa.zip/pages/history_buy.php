<?php
$thxk = new member;
$byshopme = $thxk->byshopme_api();
$resultuser = $thxk->resultuser();
$history_shop = $thxk->history_shop();
?>
<div class="container-fluid mt-3 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-3 mt-4 mb-3" data-aos="zoom-in" data-aos="700">
            <center>
                <h4 >ประวัติการซื้อสินค้า</h4>
                <h4>ใช้งานผิดวิธีทางร้านไม่รับผิดชอบทุกกรณี</h4>
            </center>
            <div class="table-responsive">
                <table id="history_buy" class="table table-striped table-dark text-center" style="width:100%">
                    <thead>
                        <tr>
                            <th width="11%">#</th>
                            <th width="23%">สินค้า</th>
                            <th width="30%">ข้อมูลสินค้า</th>
                            <th>ราคาสินค้า</th>
                            <th>สถานะ</th>
                            <th width="15%">เวลา</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($history_shop as $row) { ?>
                            <tr>
                                <th scope="row">
                                    <?php echo $row['id']; ?>
                                </th>
                                <td>
                                    <?php echo $row['name']; ?>
                                </td>
                                <td>
                                    <?php echo $row['details']; ?>
                                </td>
                                <td>
                                    <?php echo $row['price']; ?>
                                </td>
                                <td>
                                    <a>ปกติ</a>
                                </td>
                                <td>
                                    <?php echo $row['date']; ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
            $('#history_buy').dataTable({
                "order": [
                    [0, 'desc']
                ],
                "columnDefs": [{
                    "className": "dt-center",
                    "targets": "_all"
                }],
                "oLanguage": {
                    "sLengthMenu": "แสดง _MENU_ เร็คคอร์ด ต่อหน้า",
                    "sZeroRecords": "ไม่เจอข้อมูลที่ค้นหา",
                    "sInfo": "แสดง _START_ ถึง _END_ ของ _TOTAL_ เร็คคอร์ด",
                    "sInfoEmpty": "แสดง 0 ถึง 0 ของ 0 เร็คคอร์ด",
                    "sInfoFiltered": "(จากเร็คคอร์ดทั้งหมด _MAX_ เร็คคอร์ด)",
                    "sSearch": "ค้นหา :",
                    "aaSorting": [
                        [0, 'asc']
                    ],
                    "oPaginate": {
                        "sFirst": "หน้าแรก",
                        "sPrevious": "ก่อนหน้า",
                        "sNext": "ถัดไป",
                        "sLast": "หน้าสุดท้าย"
                    },
                }
            });
</script>