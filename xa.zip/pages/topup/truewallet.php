<?php
$thxk = new member;
$topup_config = $thxk->topup_config();
?>
<div class="container-fluid mt-3 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-duotone fa-building-columns fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ช่องทางการเติมเงินผ่าน TRUEWALLET</h3>
        </div>
        <div class="class-thxk p-4" data-aos="zoom-in" data-aos="700">
            <center>
                <div class="col-lg-4 mb-3">
                    <img class="img-fluid" src="https://www.truemoney.com/wp-content/uploads/2020/12/truemoneywallet-logo-20190424.png">
                    <button class="btn btn-danger w-50" data-bs-toggle="modal" data-bs-target="#howtowallet">วิธีการเติมเงิน</button>
                    <?php
                    $wallet_fee = $topup_config['wallet_fee'];
                    if ($wallet_fee === "on") {
                        echo "<p class='mt-3'>หักค่าธรรมเนียม 2.3%</p>";
                    } elseif ($wallet_fee === "off") {
                        echo "<p class='mt-3'>ไม่มีหักค่าธรรมเนียม 2.3%</p>";
                    }
                    ?>
                </div>
                <div class="col-12 col-lg-8">
                    <input type="text" class="form-control mb-3" id="link_wallet" aria-label="link_wallet" placeholder="กรุณากรอกลิงค์ซองอั่งเปา">
                    <button class="btn btn-danger w-50" id="submit_wallet">ยืนยันการเติมเงิน TrueWallet</button>
                </div>
            </center>
        </div>
    </div>
</div>
<script src="/js/truewallet.js"></script>
<!--- HOW TO BUILD ANGPAO --->
<div class="modal fade" id="howtowallet" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!--- <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">วิธีการเติมเงิน</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div> --->
            <div class="modal-body text-center">
                <img class="img-fluid" src="https://media.discordapp.net/attachments/1170611526453956628/1170749660130983967/aungpao_01.jpg?ex=655a2c96&is=6547b796&hm=ac24080cc8676ee25d143a1981e597eda641f16800c424e43a056ec73061afb1&=&width=705&height=470">
                <img class="img-fluid" src="https://media.discordapp.net/attachments/1170611526453956628/1170749660474904597/aungpao_02.jpg?ex=655a2c96&is=6547b796&hm=b9fc39fdedcc86e86bf138ad5f015475b736267d5f2e0f8e45a05fcd395bc5b3&=&width=705&height=470">
                <img class="img-fluid" src="https://media.discordapp.net/attachments/1170611526453956628/1170749660797874226/aungpao_03.jpg?ex=655a2c96&is=6547b796&hm=b90a9c4a8daf3a560ba2dd6d0ca0a6d4dcf1c49d02594704d103eab8f43b7bdd&=&width=705&height=470">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>