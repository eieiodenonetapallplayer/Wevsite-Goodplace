<div class="container-fluid mt-3 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-duotone fa-wallet fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ช่องทางการเติมเงินผ่าน PROMPTPAY</h3>
        </div>
        <div class="class-thxk p-4" data-aos="zoom-in" data-aos="700">
            <center>
                <div class="d-flex flex-wrap justify-content-center align-items-center mb-3 gap-3">
                    <img class="img-fluid" src="/assets/bank_icon/bay.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/bbl.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/gsb.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/kbank.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/ktb.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/scb.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/ttb.png" width="75px">
                    <img class="img-fluid" src="/assets/bank_icon/wallet.png" width="75px">
                </div>
                <div class="col-lg-4">
                    <img id="slipImage" src="/assets/promptpay.png" style="width:300px; height:300px; border-radius:2vh;" class="img-fluid mb-3">
                </div>
                <p style="color:red"><i class="fa-solid fa-circle-exclamation"></i> กรุณาเตรียมแอปธนาคารของท่านให้พร้อมสแกนจ่ายผ่าน QR Code</p>
                <p style="color:red"><i class="fa-solid fa-circle-exclamation"></i> รองรับการสแกนจ่ายพร้อมเพย์ทุกธนาคาร</p>
                <div class="col-12 col-lg-8">
                    <div class="mt-2 mb-2 form-floating">
                        <input type="number" class="form-control" id="amount" placeholder="amount">
                        <label for="floatingPassword"><i class="fa-solid fa-sack-dollar"></i> กรอกจำนวนเงินที่ต้องการเติม</label>
                    </div>
                    <button class="btn btn-danger w-50" id="submit_promptpay"><i class="fa-sharp fa-solid fa-circle-check"></i> ยืนยันการเติมเงิน</button>
                </div>
            </center>
        </div>
    </div>
</div>
<script src="/js/promptpay.js"></script>