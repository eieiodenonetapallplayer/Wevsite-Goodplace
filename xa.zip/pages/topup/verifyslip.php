<?php
$thxk = new member;
$topup_config = $thxk->topup_config();
?>
<div class="container-fluid mt-3 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-duotone fa-wallet fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ช่องทางการเติมเงินผ่าน MOBILE BANKING</h3>
        </div>
        <div class="class-thxk p-4" data-aos="zoom-in" data-aos="700">
            <center>
                <div class="col-lg-4">
                    <img id="slipImage" src="https://apiportal.kasikornbank.com/bucket/SiteCollectionDocuments/assets/theme/img/type-img-04.png" class="img-fluid mb-3">
                </div>
                <h5><i class="fa-duotone fa-building-columns" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ธนาคาร : <?php echo $topup_config['name_bank']; ?> </h5>
                <h5><i class="fa-duotone fa-user" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ชื่อบัญชี : <?php echo $topup_config['name_account']; ?> </h5>
                <h5><i class="fa-duotone fa-file-invoice" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> เลขบัญชี : <?php echo $topup_config['number_bank']; ?> <i id="copyNumberBank" class="fa-solid fa-copy" style="color: #ffffff;"></i></h5>
                <div class="col-12 col-lg-8">
                    <input type="file" id="slipInput" accept="image/*" class="form-control mb-3">
                    <button class=" btn btn-danger w-50" id="submit_verifyslip">ตรวจสอบสลิป</button>
                </div> <br>
                <h5> โปรดอ่านทำความเข้าใจอย่างละเอียดก่อน </h5>
                <p> หากเติมเงินแล้วขึ้นQR Playload ให้กด Crtl + f5 รัวๆ หรือเปลี่ยนBrowser (สำหรับในคอม)  </p>
                <p> สำหรับโทรศัพท์ ให้ล้างประวัติการท่องเว็บแล้วเข้าสู่ระบบใหม่  </p>
                <p> หากสลิปธนาคารของท่านเป็นชื่อภาษาอังกฤษ หรือมีแต่ชื่อไม่มีนามกสุลระบบจะไม่รองรับโปรดกดปุ่มแจ้งปํญหา ด้านขวามือ </p>
            </center>
        </div>
    </div>
</div>
<script src="/assets/js/jsQR.js"></script>
<script src="/js/verifyslip-fix.js"></script>
<script>
    var slipInput = document.getElementById("slipInput");
    var slipImage = document.getElementById("slipImage");

    slipInput.addEventListener("change", function(event) {
        var file = event.target.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                slipImage.src = e.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            slipImage.src = ""; // ล้างรูปภาพถ้าไม่มีไฟล์ที่เลือก
        }
    });
</script>
<script>
    document.getElementById("copyNumberBank").addEventListener("click", function() {
        var numberBank = "<?php echo $topup_config['number_bank']; ?>";
        var textArea = document.createElement("textarea");
        textArea.value = numberBank;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        Swal.fire({
            icon: 'success',
            title: 'คัดลอกเลขบัญชีแล้ว',
        });
    });
</script>