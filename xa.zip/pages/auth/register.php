<?php
$thxk = new member;
$webconfig = $thxk->webconfig();
?>
<div class="container mt-5">
    <div class="card-body" style="box-shadow: 0 2px 4px 0 rgba(0,0,0,.2);">
        <div class="form-signin">
            <form>
                <div class="text-center"><br>
                    <img src="<?php echo $webconfig['logo']; ?>" class="img-fluid" width="80%">
                    <!--- <h2 class="fw-bold">YOURNAME</h2> --->
                    <p class="mb-3 fw-normal text-head">สมัครสมาชิก</p>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="username" placeholder="Username">
                        <label for="floatingInput"><i class="fa fa-user" aria-hidden="true"></i> ชื่อผู้ใช้</label>
                    </div>
                    <div class="mt-2 form-floating">
                        <input type="email" class="form-control" id="email" placeholder="name@example.com">
                        <label for="floatingInput"><i class="fa-solid fa-envelope"></i> อีเมล</label>
                    </div>
                    <div class="mt-2 form-floating">
                        <input type="password" class="form-control" id="password" placeholder="Password">
                        <label for="floatingPassword"><i class="fa fa-unlock-alt" aria-hidden="true"></i> รหัสผ่าน</label>
                    </div>
                    <div class="mt-2 mb-2 form-floating">
                        <input type="password" class="form-control" id="password_confirm" placeholder="Password">
                        <label for="floatingPassword"><i class="fa fa-unlock-alt" aria-hidden="true"></i> ยืนยันรหัสผ่าน</label>
                    </div>
                </div>
                <button class="btn btn-danger w-100 mb-2" type="button" id="submit_register">สมัครสมาชิก</button>
                <a class="btn btn-dark w-100 mb-2" type="button" href="/">หน้าหลัก</a>
            </form>
        </div>
    </div>
</div>
<script src="/js/register.js"></script>