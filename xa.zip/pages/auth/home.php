<?php
$thxk = new member;
$webconfig = $thxk->webconfig();
$product_self = $thxk->card_product();
$category = $thxk->show_category();
$products = $thxk->products_byshopme();
$count_member = $thxk->count_member();
$count_category = $thxk->count_category();
$count_product_ready = $thxk->count_product_ready();
$count_stock_buyed = $thxk->count_stock_buyed();
$history_social = $thxk->history_social();
$cate_topupgames = $thxk->cate_topupgames();
$service = $thxk->service();
?>
<style>
    .btn-main {color: var(--clr-neon);background: var(--clr-neon-30);border: 1px solid var(--clr-neon);transition: all .5s ease;}
    .btn-main.active {color: white;background-color: var(--clr-neon);border: 1px solid var(--clr-neon);}
    .btn-main.active i {color: white !important;}
    .btn-main:hover {color: white;background-color: var(--clr-neon);border: 1px solid var(--clr-neon);}
    @media only screen and (max-width: 500px) {.pd-sm-font {font-size: 13px !important;}.pd-h-font {font-size: 16px;}}.card-anim-main {border: 1px solid #ffffff00;transition: all .5s ease;}
    .card-anim:hover .card-anim-main {border: 1px solid var(--clr-neon);}
    .modal-content {
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(5px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
        box-shadow: 2px rgba(11, 11, 11, 0.3);
    }

    .grayscale {
        filter: grayscale(100%);
        -webkit-filter: grayscale(100%);
    }
</style>
<div class="container-fluid mt-4 p-0" data-aos="zoom-in">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <h1 style="color:#fff;"><?php echo $apiKey['apikey'] ?></h1>
        <div id="carouselExampleControls" class="carousel slide carousel-fade" data-bs-ride="carousel" style="border-radius: 2vh;">
            <div class="carousel-inner" style="border-radius: 2vh;">
                <?php
                $thxk = new member;
                $slide_picture = $thxk->slide_picture();
                ?>
                <?php foreach ($slide_picture as $index => $picture) { ?>
                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                        <img src="<?php echo $picture['link_picture']; ?>" class="d-block w-100" alt="..." style="border-radius: 2vh;">
                    </div>
                <?php } ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                <span class="carousel-control-next-icon" ariahidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
</div>
<div class="container-fluid mt-4 p-0" data-aos="zoom-in">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="row">
            <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
                <div class="class-thxk border-glowing-v2 p-3" style="border-radius: 2vh 5vh 2vh 5vh;">
                    <img src="https://kyoji.org/assets/11.png" class="img-fluid" width="75px">
                    <h5 class="mt-2">จำนวนสมาชิก</h5>
                    <p><?php echo $count_member['total']; ?> คน</p>
                </div>
            </div>
            <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
                <div class="class-thxk border-glowing-v2 p-3" style="border-radius: 2vh 5vh 2vh 5vh;">
                    <img src="https://kyoji.org/assets/12.png" class="img-fluid" width="75px">
                    <h5 class="mt-2">หมวดหมู่สินค้า</h5>
                    <p><?php echo $count_category['total']; ?> รายการ</p>
                </div>
            </div>
            <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
                <div class="class-thxk border-glowing-v2 p-3" style="border-radius: 2vh 5vh 2vh 5vh;">
                    <img src="https://kyoji.org/assets/13.png" class="img-fluid" width="75px">
                    <h5 class="mt-2">สินค้าพร้อมขาย</h5>
                    <p><?php echo $count_product_ready['total'] - 99999; ?> รายการ</p>
                </div>
            </div>
            <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
                <div class="class-thxk border-glowing-v2 p-3" style="border-radius: 2vh 5vh 2vh 5vh;">
                    <img src="https://kyoji.org/assets/16.png" class="img-fluid" width="75px">
                    <h5 class="mt-2">สินค้าขายแล้ว</h5>
                    <p><?php echo $count_stock_buyed['total']; ?> รายการ</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- แนะนำวิธีใช้งาน -->
<!--div class="container-fluid mt-4 p-0" data-aos="zoom-in">
    <div class="container p-4 pt-0 pb-0 m-cent">
<div class="row">
    <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
        <a href="https://s-organization-195.gitbook.io/untitled-1/"
            target="_blank">
            <img src="https://img2.pic.in.th/pic/rrr.png" class="img-fluid img-sm-responsive" alt="Image description"
                style=" height: 170px; width: 100%; border-radius: 15px; border: 1px solid #000;">
        </a>
    </div>
    <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
        <a href="https://www.facebook.com/photo/?fbid=122144574398010079&set=a.122115732986010079" target="_blank">
            <img src="https://img2.pic.in.th/pic/44e04563dd0135bccd299e0697c44915.png" class="img-fluid img-sm-responsive" alt="Image description"
                style=" height: 170px; width: 100%; border-radius: 15px; border: 1px solid #000;">
        </a>
    </div>
    <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
        <a href="../app">
            <img src="https://img5.pic.in.th/file/secure-sv1/-1faa2ca918417a676.png" class="img-fluid img-sm-responsive" alt="Image description"
                style=" height: 170px; width: 100%; border-radius: 15px; border: 1px solid #000;">
        </a>
    </div>
    <div class="col-6 col-md-3 col-sm-12 mb-3 text-center">
        <a href="https://s-organization-195.gitbook.io/untitled-1/steam"
            target="_blank">
            <img src="https://img5.pic.in.th/file/secure-sv1/-2eaeef773bcd5bcfc.png" class="img-fluid img-sm-responsive" alt="Image description"
                style=" height: 170px; width: 100%; border-radius: 15px; border: 1px solid #000;">
        </a-->
    </div> 
    </div>
    </div>
    </div>
<div class="container-fluid mt-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-2" style="border-radius: 2vh;">
            <div class="d-flex flex-row align-items-center">
                <marquee direction="left" style="color: #ffffff; font-size: 100%" class="d-flex mr-5 mt-3">
                    <p><?php echo $webconfig['keywords']; ?></p>
                </marquee>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mt-3"><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติปั้มโซเชียล <small>( 10รายการล่าสุด )</small></h4>
            <a href="/shoping" class="btn btn-thxk">เพิ่มเติม</a>
        </div>
        <div class="class-thxk shadow" style="border-radius: 10px;">
            <marquee direction="left">
                <div class="d-flex flex-row ">

                    <?php 
                        $limit = 10; // จำนวนรายการที่ต้องการแสดง
                        $history_social = array_slice($history_social, - $limit);
                        foreach ($history_social as $social) { 
                    ?>
                        <div class=" d-flex mr-5 mt-3 text-black"> 
                        <br>  
                        <img class="img-fluid rounded" style="margin:0 auto;  height: 50px;" src="">
                        <span><b>&nbsp;&nbsp;&nbsp;<?php echo $social['list'] ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
                        <br>&nbsp;&nbsp;&nbsp;<?php echo $social['timeadd'] ?><br>
                        <b><p style="font-size: 13px">&nbsp;&nbsp;<span class="rounded-pill badge bg-success">&nbsp;&nbsp;สั่งซื้อสำเร็จ !! &nbsp;&nbsp;</span>&nbsp;<span class="rounded-pill badge bg-main text-white">&nbsp;&nbsp;ผู้ซื้อ <?php echo $social['username'] ?>&nbsp;&nbsp;</span></b></p>
                        </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
                    <?php } ?>
                </div>
            </marquee>
        </div>
    </div>
</div>

<div class="container-fluid mt-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mt-3"><i class="fa-duotone fa-layer-group"></i> หมวดหมู่สินค้า</h4>
            <a href="/shoping" class="btn btn-thxk">เพิ่มเติม</a>
        </div>
        <div class="row">
            <?php foreach (array_slice($category, 0, 4) as $categoryItem) { ?>
                <div class="col-6 col-md-6 col-sm-12 mb-3" data-aos="zoom-in">
                    <a href="/product?type=<?php echo $categoryItem['name'] ?>">
                        <img src="<?php echo $categoryItem['img']; ?>" style="border-radius:2vh;" class="border-glowing img-fluid">
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<div class="container-fluid mt-2 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mt-3"><i class="fa-duotone fa-gamepad-modern"></i> บริการไอดีพาส</h4>
            <a href="/service" class="btn btn-thxk">ดูเพิ่มเติม</a>
        </div>
        <div class="row">
            <?php foreach ($service as $row) { ?>
                <div class="col-6 col-md-6 col-sm-12 mb-3" data-aos="zoom-in">
                    <a href="/service?category=<?php echo $row['name'] ?>">
                        <img src="<?php echo $row['img']; ?>" style="border-radius:2vh;" class="border-glowing img-fluid">
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<div class="container-fluid mt-4 mb-4 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mt-3"><i class="fa-duotone fa-bags-shopping"></i> สินค้าแนะนำ</h4>
            <a href="/shoping" class="btn btn-thxk">ดูเพิ่มเติม</a>
        </div>
        <div class="row">
            <?php foreach (array_slice($product_self, 0, 12) as $product) {
                $totalproduct = $thxk->totalproduct($product['id']);  ?>
                <div class="col-6 col-lg-3 mb-3" data-aos="zoom-in">
                    <div class="card-body border-glowing p-3" style="border-radius:1vh;">
                        <?php
                        $imgClasses = 'img-fluid';
                        ?>
                        <img class="<?= $imgClasses ?>" style="border-radius:1vh;" src="<?= $product['image_product']; ?>" alt="<?= $product['name_product']; ?>">
                        <hr style="color:#999;">
                        <div class="p-2">
                            <p style="font-size:17px;"><?php echo $product['name_product']; ?></p>
                            <p style="font-size:16px;">ราคา&nbsp;<?php echo $product['price_product']; ?>฿</p>
                            <p style="font-size:16px;">สินค้าคงเหลือ&nbsp;<?php echo $totalproduct['total']; ?>&nbsp;รายการ</p>
                            <button class="btn btn-danger py-2 w-100" data-bs-toggle="modal" data-bs-target="#productModal<?= $product['id']; ?>" data-id="<?= $product['id']; ?>"><i class="fa-duotone fa-bag-shopping"></i>&nbsp;สั่งซื้อสินค้า</button>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php foreach ($product_self as $product) { ?>
    <div class="modal fade" id="productModal<?= $product['id']; ?>" tabindex="-1" aria-labelledby="productModalLabel<?= $product['id']; ?>" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <?php
                            $imgClasses = 'img-fluid';
                            ?>
                            <img class="mb-2 <?= $imgClasses ?>" style="border-radius:2vh" src="<?= $product['image_product']; ?>" alt="<?= $product['name_product']; ?>">
                        </div>
                        <div class="col-12 col-lg-6">
                            <h5><?= $product['name_product']; ?></h5>
                            <hr>
                            <p><?= $product['details_product']; ?></p>
                        </div>
                        <div class="row p-2 align-items-center text-center">
                            <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                <a class="neon-button w-100" data-bs-dismiss="modal">ยกเลิก</a>
                            </div>
                            <div class="col-12 col-lg-6">
                                <?php if (empty($_SESSION['username'])) { ?>
                                    <a href="/login" class="neon-button w-100">กรุณาเข้าสู่ระบบก่อน</a>
                                <?php } else { ?>
                                    <a class="submit_buyproduct neon-button w-100" data-product-id="<?php echo $product['id']; ?>" data-product-name="<?php echo $product['name_product']; ?>" data-product-price="<?php echo $product['price_product']; ?>">
                                        ซื้อสินค้า <?php echo $product['price_product']; ?>฿
                                    </a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<script src="/js/buyproduct_stock.js"></script>

<div class="container-fluid mt-2 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mt-3"><i class="fa-duotone fa-gamepad-modern"></i> เติมเกมออนไลน์</h4>
            <a href="/topupgame" class="btn btn-thxk">ดูเพิ่มเติม</a>
        </div>
        <div class="row">

            <?php foreach ($cate_topupgames as $cate) { ?>
                <div class="col-3 col-lg-3 mt-3 mb-3" data-aos="zoom-in">
                    <a href="/topupgame<?php echo $cate['link']; ?>">
                        <img class="img-fluid border-glowing" style="border-radius:2vh" src="<?php echo $cate['img']; ?>" alt="<?php echo $cate['name']; ?>">
                    </a>
                </div>
            <?php } ?>

        </div>
    </div>
</div>

<div class="container-fluid mt-2 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="mt-3"><i class="fa-duotone fa-bags-shopping"></i> แอพสตรีมมิ่ง</h4>
            <a href="/app" class="btn btn-thxk">ดูเพิ่มเติม</a>
        </div>
        <div class="row">
            <?php foreach (array_slice($products, 0, 8) as $product) { ?>
                <?php if ($product['product_status'] === 'on') { ?>
                    <div class="col-6 col-lg-3 mt-3 mb-3" data-aos="zoom-in">
                        <?php
                        $imgClasses = 'img-fluid border-glowing';
                        if ($product['api_stock'] == 0) {
                            $imgClasses .= ' grayscale'; // ใส่คลาส CSS "grayscale" ถ้า stock เป็น 0
                        }
                        ?>
                        <a href="/app">
                            <img class="<?= $imgClasses ?>" style="border-radius:2vh" data-bs-toggle="modal" data-bs-target="#productModal-<?= $product['product_code']; ?>" data-id="<?= $product['product_code']; ?>" src="<?= $product['product_image']; ?>" alt="<?= $product['product_name']; ?>">
                        </a>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
</div>

<!-- <div class="container-sm">
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="mt-3"><i class="fa-duotone fa-thumbs-up"></i> บริการปั้มโซเชียล</h4>
        <a href="/socialbooster" class="btn btn-thxk">ดูเพิ่มเติม</a>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="bg-navvx p-2 mt-4">
                <div class="p-2">
                    <h4><b><center>เลือกบริการที่ต้องการ</center></b></h4>
                    <br>
                    <label for="category" class="text-white">หมวดหมู่ <span class="text-red">*</span></label>
                    <select class="form-select mt-1" name="category" id="category">
                        <option value="19">รวมโปรโมชั่นพิเศษวันนี้</option>
                        <option value="19">All-Social 🆕</option>
                    </select>
                    <br>
                    <label for="services" class="text-white">บริการที่ต้องการ <span class="text-red">*</span></label>
                    <select class="form-select mt-1" name="services" id="services"></select>
                    <br>
                    <div class="form-group">
                        <label for="serviceDetails" class="text-white">รายละเอียดบริการ</label>
                        <textarea class="form-control mt-1" id="serviceDetails" rows="3" disabled></textarea>
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="link" class="text-white">ลิ้งค์ <span class="text-red">*</span></label>
                        <input type="text" name="link" id="link" class="form-control mt-1" placeholder="ลิ้งค์" required />
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="squantity" class="text-white">จำนวน <span class="text-red">*</span></label>
                        <input type="number" name="squantity" id="squantity" class="form-control mt-1" placeholder="จำนวน" required />
                    </div>
                    <span class="badge bg-danger" id="minOrder">ขั้นต่ำ: 10-1000</span>
                    <span class="badge bg-success" id="maxOrder">สูงสุด: 400000</span>
                    <br>
                    <div class="form-group">
                        <label for="charge" class="text-white">อัตราค่าบริการ <span class="text-red">*</span></label>
                        <input type="text" name="charge" id="charge" class="form-control mt-1" placeholder="อัตราค่าบริการ" disabled />
                    </div>
                    <br>
                    <div class="d-grid gap-2">
                        <button class="btn btn-success" id="social-booster" disabled>ทำรายการ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $("#social-booster").click(function () {
        var formData = new FormData();

        var selectedService = document.getElementById('services').value;
        var match = selectedService.match(/ID (\d+)/);
        var selectedServiceId = match ? match[1] : null;

        formData.append('id', selectedServiceId);
        formData.append('link', $("#link").val());
        formData.append('squantity', $("#squantity").val());

        $.ajax({
            type: 'POST',
            url: '../systems/socialbooster/socialbooster.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            result = res;

            if (result.status == "success") {
                Swal.fire({
                    icon: 'success',
                    title: 'สำเร็จ',
                    text: result.message
                }).then(function () {
                    window.location = "?page=socialbooster";
                });
            }

            if (result.status == "fail") {
                Swal.fire({
                    icon: 'error',
                    title: 'ผิดพลาด',
                    text: result.message
                });
                $('#social-booster').removeAttr('disabled');
            }
        }).fail(function (jqXHR) {
            console.log(jqXHR);
            res = jqXHR.responseJSON;

            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: res.message
            });
            $('#social-booster').removeAttr('disabled');
        });
    });

    function calculateTotalCharge() {
        var selectedService = document.getElementById('services').value;
        var selectedServiceName = document.getElementById('services').options[document.getElementById('services').selectedIndex].text;

        var priceRegex = /(\d+\.\d{2}) บาท$/;
        var match = selectedServiceName.match(priceRegex);

        if (match) {
            var extractedPrice = parseFloat(match[1]) / 1000;

            var quantity = parseFloat(document.getElementById('squantity').value);

            if (!isNaN(quantity) && quantity > 0) {
                var totalPrice = extractedPrice * quantity;
                document.getElementById('charge').value = 'ราคารวม: ' + totalPrice.toFixed(2) + ' บาท';
            } else {
                document.getElementById('charge').value = 'กรุณาใส่จำนวนที่ถูกต้อง';
            }
        } else {
            document.getElementById('charge').value = 'ไม่สามารถสกัดราคาได้';
        }
    }

    document.getElementById('services').addEventListener('change', calculateTotalCharge);
    document.getElementById('squantity').addEventListener('input', calculateTotalCharge);

    document.getElementById('services').addEventListener('change', function () {
        calculateTotalCharge();

        var selectedOption = this.options[this.selectedIndex];
        var serviceDetails = selectedOption.getAttribute('data-description');
        document.getElementById('serviceDetails').value = serviceDetails ? serviceDetails : 'ไม่พบรายละเอียด';
    });

    $(document).ready(function () {
        <?php
        $result_load_packz = dd_q("SELECT * FROM socialservice");
        $servicesFromDatabase = [];
        while ($row = $result_load_packz->fetch(PDO::FETCH_ASSOC)) {
            $serviceOption = "- ID {$row['id']} {$row['name']} {$row['price']} บาท";
            $serviceDescription = $row['des'];
            $servicesFromDatabase[] = ['option' => $serviceOption, 'description' => $serviceDescription];
        }
        ?>
        var categoryServices = {
            "19": ["รวมโปรโมชั่นพิเศษวันนี้"],
            "19": <?php echo json_encode($servicesFromDatabase); ?>
        };

        $("#category").change(function () {
            var selectedCategory = $(this).val();
            var services = categoryServices[selectedCategory] || [];

            $("#services").empty();
            $.each(services, function (index, service) {
                var option = $('<option>', {
                    value: service.option,
                    text: service.option.split(' ').slice(3).join(' '),
                    'data-description': service.description
                });
                $("#services").append(option);
            });

            $("#social-booster").prop("disabled", services.length === 0);
        });
    });
</script> -->