<?php
$thxk = new member;
$webconfig = $thxk->webconfig();
?>
<div class="container mt-5">
    <div class="card-body">
        <div class="form-signin">
            <form>
                <div class="text-center"><br>
                    <img src="<?php echo $webconfig['logo']; ?>" class="img-fluid" width="80%">
                    <!--- <h2 class="fw-bold">YOURNAME</h2> --->
                    <p class="mb-3 fw-normal text-head">เข้าสู่ระบบ</p>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="username" placeholder="Username">
                        <label for="floatingInput"><i class="fa fa-user" aria-hidden="true"></i> ชื่อผู้ใช้</label>
                    </div>
                    <div class="mt-2 mb-2 form-floating">
                        <input type="password" class="form-control" id="password" placeholder="Password">
                        <label for="floatingPassword"><i class="fa fa-unlock-alt" aria-hidden="true"></i> รหัสผ่าน</label>
                    </div>
                </div>
                <button class="btn btn-danger w-100 mb-2" type="button" id="submit_login">เข้าสู่ระบบ</button>
                <a class="btn btn-dark w-100 mb-2" type="button" href="/register">สมัครสมาชิก</a>
            </form>
        </div>
    </div>
</div>
<script src="/js/login.js"></script>