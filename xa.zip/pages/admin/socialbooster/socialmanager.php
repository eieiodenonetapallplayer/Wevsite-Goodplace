<?php
$thxk = new member;
$socialservice = $thxk->socialservice();
$product_category = $thxk->show_category();
?>
<div class="container-fluid mt-2 p-0">
    <?php include 'layouts/nav_admin.php'; ?>
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center"><i class="fa-duotone fa-thumbs-up"></i> จัดการรายการ</h3>
        </div>
        <div class="class-thxk  p-4 mb-3" data-aos="zoom-in">
            <div class="table-responsive">
                <table id="productstorck" class="table table-striped table-dark" style="width:100%">
                    <div class="container-fluid btn btn-dark p-3 mb-3" style="border-radius: 1vh;">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#addProductModel" style="text-decoration: none;">
                            <center>
                                <i class="fa-duotone fa-thumbs-up fa-xl" style="color: #ffffff;"></i>
                                <h5 class="ms-1 mb-0 mt-2">เพิ่มรายการ</h5>
                            </center>
                        </a>
                    </div>
                    <thead>
                        <tr>
                            <th width="5%">id</th>
                            <th width="20%">dataid</th>
                            <th width="5%">service</th>
                            <th width="30%">price</th>
                            <th width="15%">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($socialservice as $s) : ?>
                            <tr>
                                <td class=""><?php echo $s['id']; ?></td>
                                <td class=""><?php echo $s['idapi']; ?></td>
                                <td class=""><?php echo $s['name']; ?>
                                    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#view<?php echo $s['id']; ?>">checkname</button>
                                </td>
                                <td class=""><?php echo $s['price']; ?></td>
                                <td>
                                    <button data-id="<?php echo $s['id']; ?>" data-bs-toggle="modal" data-bs-target="#editProductModal" class="btn btn-warning w-100 p-2 mb-2" style="width: 130px!important"><i class="fa-solid fa-pencil"></i>&nbsp;แก้ไข</button>
                                    <button id_del="<?php echo $s['id']; ?>" class="btn btn-danger w-100 del_service_id p-2 mb-2" style="width: 130px!important"><i class="fa-solid fa-trash"></i> ลบ</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php foreach ($socialservice as $s) : ?>
    <div class="modal fade" id="view<?php echo $s['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title text-dark fs-5" id="exampleModalLabel">ID รายการ : <?php echo $s['id']; ?></h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo $s['name']; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<!-- addProductModel -->
<div class="modal fade" id="addProductModel" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" style="font-weight:bold" id="exampleModalLabel"><i class="fa-duotone fa-cart-shopping"></i>&nbsp;&nbsp;เพิ่มสินค้า</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-lg-12 m-cent ">
                    <div class="mb-2">

                        <div class="mb-2">
                            <p class="mb-2 text-dark">dataid <span class="text-danger">*</span></p>
                            <input type="text" id="idapi" class="form-control" placeholder="กรอกดาต้าไอดี">
                        </div>
                        <div class="mb-2">
                            <p class="mb-2 text-dark">name <span class="text-danger">*</span></p>
                            <input type="text" id="name" class="form-control" placeholder="กรอกชื่อบริการ">
                        </div>
                        <div class="mb-2">
                            <p class="mb-2 text-dark">des <span class="text-danger">*</span></p>
                            <textarea name="des" id="des" class="form-control"placeholder="กรอกรายละเอียด"></textarea>
                        </div>
                        <div class="mb-2">
                            <p class="mb-2 text-dark">price <span class="text-danger">*</span></p>
                            <input type="text" id="price" class="form-control" placeholder="กรอกราคา">
                        </div>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary ps-4 pe-4" id="submit_add_service" data-id="">เพิ่มสินค้า</button>
            </div>
        </div>
    </div>
</div>

<!-- editProductModel -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="exampleModalLabel" data-id="" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" style="font-weight:bold" id="exampleModalLabel"><i class="fa-duotone fa-pencil"></i>&nbsp;&nbsp;แก้ไขบริการ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-lg-12 m-cent">
                    <div class="mb-2">
                        <div class="mb-2">
                        
                            <input type="hidden" id="edit_id" value="">
                            <p class="mb-2 text-dark">dataid <span class="text-danger">*</span></p>
                            <input type="text" id="edit_idapi" class="form-control" value="">
                            <p class="mb-2 text-dark">name <span class="text-danger">*</span></p>
                            <input type="text" id="edit_name" class="form-control" value="">
                            <p class="mb-2 text-dark">des <span class="text-danger">*</span></p>
                            <textarea name="edit_desss" id="edit_desss" class="form-control"></textarea>
                            <p class="mb-2 mt-2 text-dark">price <span class="text-danger">*</span></p>
                            <input type="text" id="edit_price" class="form-control" value="">
                        
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary ps-4 pe-4" id="submit_edit_service">อัพเดท</button>
            </div>
        </div>
    </div>
</div>

<script>
            $('#productstorck').dataTable({
                "order": [
                    [0, 'asc']
                ],
                "columnDefs": [{
                    "className": "dt-center",
                    "targets": "_all"
                }],
                "oLanguage": {
                    "sLengthMenu": "แสดง _MENU_ เร็คคอร์ด ต่อหน้า",
                    "sZeroRecords": "ไม่เจอข้อมูลที่ค้นหา",
                    "sInfo": "แสดง _START_ ถึง _END_ ของ _TOTAL_ เร็คคอร์ด",
                    "sInfoEmpty": "แสดง 0 ถึง 0 ของ 0 เร็คคอร์ด",
                    "sInfoFiltered": "(จากเร็คคอร์ดทั้งหมด _MAX_ เร็คคอร์ด)",
                    "sSearch": "ค้นหา :",
                    "aaSorting": [
                        [0, 'desc']
                    ],
                    "oPaginate": {
                        "sFirst": "หน้าแรก",
                        "sPrevious": "ก่อนหน้า",
                        "sNext": "ถัดไป",
                        "sLast": "หน้าสุดท้าย"
                    },
                }
            });
</script>
<script>
    $(document).on('click', '[data-bs-toggle="modal"][data-bs-target="#editProductModal"]', function() {
        var id = $(this).data('id');
        var productData = <?php echo json_encode($socialservice); ?>;
        var selectedData = productData.find(function(item) {
            return item.id == id;
        });
        if (selectedData) {
            $("#edit_id").val(selectedData.id);
            $("#edit_idapi").val(selectedData.idapi);
            $("#edit_name").val(selectedData.name);
            $("#edit_desss").val(selectedData.des);
            $("#edit_price").val(selectedData.price);
        }
    });
</script>
<script src="/js/service_stock.js"></script>
<script src="/js/edit_product_service.js"></script>
<script src="/js/del_product_service.js"></script>