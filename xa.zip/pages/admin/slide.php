<?php
$thxk = new member;
$slide_picture = $thxk->slide_picture();
?>
<div class="container-fluid mt-2 p-0">
    <?php include 'layouts/nav_admin.php'; ?>
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center"><i class="fa-sharp fa-solid fa-folder-image fa-xl" style="color: #ffffff;"></i> ระบบแก้ไขภาพสไลด์</h3>
        </div>
        <div class="class-thxk text-center p-4 mb-3" data-aos="zoom-in">
            <div class="table-responsive">
                <table class="table table-striped table-dark" style="width:100%">
                    <div class="container-fluid btn btn-dark p-3 mb-3" style="border-radius: 1vh;">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#addImageModal" style="text-decoration: none;">
                            <center>
                                <i class="fa-sharp fa-solid fa-images fa-xl" style="color: #ffffff;"></i>
                                <h5 class="ms-1 mb-0">เพิ่มรูปภาพใหม่</h5>
                            </center>
                        </a>
                    </div>
                    <thead>
                        <tr>
                            <th class="sorting sorting_asc">ไอดี</th>
                            <th>ลิงค์รูปภาพ</th>
                            <th>อัพเดทล่าสุด</th>
                            <th>จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($slide_picture as $picture) { ?>
                            <tr>
                                <td class=""><?php echo $picture['id']; ?></td>
                                <td class=""><img src="<?php echo $picture['link_picture']; ?>" width="250px" srcset=""></td>
                                <td class=""><?php echo $picture['date']; ?></td>
                                <td>
                                    <button data-id="<?php echo $picture['id']; ?>" data-bs-toggle="modal" data-bs-target="#editImageModal" class="btn btn-thxk w-100 p-2 mb-2" style="width: 130px!important"><i class="fa-solid fa-pencil"></i>&nbsp;แก้ไข</button>
                                    <button id_picture="<?php echo $picture['id']; ?>" class="btn btn-thxk w-100 del_picture p-2 mb-2" style="width: 130px!important"><i class="fa-solid fa-trash"></i> ลบ</button>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- addImageModel -->
<div class="modal fade" id="addImageModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" style="font-weight:bold" id="exampleModalLabel"><i class="fa-duotone fa-pencil"></i>&nbsp;&nbsp;เพิ่มรูปภาพสไลด์</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-lg-12 m-cent ">
                    <div class="mb-2">
                        <div class="mb-2">
                            <p class=" mb-1 text-dark">URL ของรูปภาพ <span class="text-danger">*</span></p>
                            <input type="text" id="link_picture" class="form-control" value="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary ps-4 pe-4" id="submit_picture" data-id="">บันทึก</button>
            </div>
        </div>
    </div>
</div>
<!-- editImageModel -->
<div class="modal fade" id="editImageModal" tabindex="-1" aria-labelledby="exampleModalLabel" data-id="" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" style="font-weight:bold" id="exampleModalLabel"><i class="fa-duotone fa-pencil"></i>&nbsp;&nbsp;แก้ไขภาพสไลด์</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="col-lg-12 m-cent">
                    <div class="mb-2">
                        <div class="mb-2">
                            <input type="hidden" id="edit_picture_id" value="">
                            <p class="mb-1 text-dark">URL ของรูปภาพ <span class="text-danger">*</span></p>
                            <input type="text" id="edit_link_picture" class="form-control" value="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary ps-4 pe-4" id="submit_edit_link_picture" data-id="">อัพเดท</button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '[data-bs-toggle="modal"][data-bs-target="#editImageModal"]', function() {
        var id = $(this).data('id');
        var pictureData = <?php echo json_encode($slide_picture); ?>;
        var selectedData = pictureData.find(function(item) {
            return item.id == id;
        });
        if (selectedData) {
            $("#edit_picture_id").val(selectedData.id);
            $("#edit_link_picture").val(selectedData.link_picture);
        }
    });
</script>

<script src="/js/edit_link_picture.js"></script>
<script src="/js/del_link_picture.js"></script>
<script src="/js/link_picture.js"></script>