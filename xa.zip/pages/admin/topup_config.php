<?php
$thxk = new member;
$topup_config = $thxk->topup_config();
?>
<div class="container-fluid mt-2 p-0">
    <?php include 'layouts/nav_admin.php'; ?>
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center"><i class="fa-solid fa-folder-gear fa-xl" style="color: #ffffff;"></i> ตั้งค่าระบบเติมเงิน</h3>
        </div>
        <div class="class-thxk p-2 mb-3" data-aos="zoom-in">
            <div class="container-fluid btn btn-dark p-3 mb-3" style="border-radius: 1vh;">
                <a id="submit_topupconfig" style="text-decoration: none;">
                    <center>
                        <i class="fa-sharp fa-solid fa-floppy-disk fa-xl" style="color: #ffffff;"></i>
                        <h5 class="ms-1 mb-0">บันทึกการตั้งค่า</h5>
                    </center>
                </a>
            </div>
            <div class="col-12">
                <div class="row">
                    <div class="col-md-6">
                        <div class="container-fluid class-menu p-4 pt-5 rounded shadow-sm border-ys count-only" style="border-radius: 1vh;">
                            <div style="text-decoration: none;">
                                <center>
                                    <h5><i class="fa-duotone fa-wallet" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> TRUEWALLET ตั้งค่าระบบเติมเงินแบบซองอั่งเปา</h5>
                                </center>
                                <hr>
                                <p class="mb-2">เบอร์โทรศัพท์ Wallet</p>
                                <input type="text" id="wallet_phone" class="form-control mb-2" value="<?php echo $topup_config['wallet_phone'] ?>">
                                <p class="mb-2">ค่าธรรมเนียม 2.3%</p>
                                <select id="wallet_fee" class="form-control mb-2">
                                    <option value="off" <?php if ($topup_config['wallet_fee'] == "off") echo "selected"; ?>>ปิด</option>
                                    <option value="on" <?php if ($topup_config['wallet_fee'] == "on") echo "selected"; ?>>เปิด</option>
                                </select>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="container-fluid class-menu p-4 pt-5 rounded shadow-sm border-ys count-only" style="border-radius: 1vh;">
                            <div style="text-decoration: none;">
                                <center>
                                    <h5><i class="fa-duotone fa-building-columns" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ตั้งค่าระบบตรวจสอบสลิป (slip.rdcw)</h5>
                                </center>
                                <hr>
                                <p class="mb-2">Client ID</p>
                                <input type="text" id="client_id" class="form-control mb-2" value="<?php echo $topup_config['client_id'] ?>">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="mb-2">Client Secret</p>
                                        <input type="text" id="client_secret" class="form-control mb-2" value="<?php echo $topup_config['client_secret'] ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <p class="mb-2">ชื่อบัญชี <span style="font-size: 14px;">(ตัวอย่าง: นาย อภิรักษ์ ส)</span></p>
                                        <input type="text" id="client_account" class="form-control mb-4" value="<?php echo $topup_config['client_account'] ?>">
                                    </div>
                                </div>

                                <!---------------------------------------------------------------------------------------------------------------------------->

                                <center>
                                    <h5 class="mt-3"><i class="fa-duotone fa-building-columns" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i> ตั้งค่าเลขบัญชีธนาคารหน้าเติมเงิน</h5>
                                </center>
                                <hr>
                                <p class="mb-2">ชื่อบัญชี</p>
                                <input type="text" id="name_account" class="form-control mb-2" value="<?php echo $topup_config['name_account'] ?>">
                                <p class="mb-2">ธนาคาร</p>
                                <input type="text" id="name_bank" class="form-control mb-2" value="<?php echo $topup_config['name_bank'] ?>">
                                <p class="mb-2">เลขบัญชี</p>
                                <input type="text" id="number_bank" class="form-control mb-2" value="<?php echo $topup_config['number_bank'] ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/js/topup_config.js"></script>