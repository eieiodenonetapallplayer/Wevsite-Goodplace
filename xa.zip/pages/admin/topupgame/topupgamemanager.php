<?php
$thxk = new member;
$cate_topupgame = $thxk->cate_topupgame();
?>
<style>
    .modal-content {
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(5px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
        box-shadow: 2px rgba(11, 11, 11, 0.3);
    }
</style>
<div class="container-fluid mt-2 p-0">
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-3 mt-4 mb-3" data-aos="zoom-in" data-aos="700">
            <center>
                <h4>จัดการเติมเกม</h4>
                <hr>
            </center>
            <div class="table-responsive">
                <table id="history_buy1" class="table table-striped table-dark text-center" style="width:100%">
                    <thead>
                        <tr>
                            <th>ไอดี</th>
                            <th width="20%">รูป</th>
                            <th width="15%">หมวดหมู่</th>
                            <th>รายละเอียด</th>
                            <th width="5%">ลิ้งค์</th>
                            <th width="5%">สถานะ</th>
                            <th width="15%">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cate_topupgame as $cate) { ?>
                        <tr>
                            <td><?= $cate['id'] ?></td>
                            <td><img src="<?php echo $cate['img']; ?>" height="200px"></td>
                            <td><?= $cate['name'] ?></td>
                            <td><?= $cate['des'] ?></td>
                            <td><?= $cate['link'] ?></td>
                            <td>
                                <?php if ($cate['status'] == 'เปิด') {?>
                                    <span class="badge text-bg-success">เปิดใช้งาน</span>
                                <?php } elseif($cate['status'] == 'ปิด' )  {?>
                                    <span class="badge text-bg-danger">ปิดใช้งาน</span>
                                <?php } ?>
                            </td>
                            <td>       
                                <a href="/admin/manager<?php echo $cate['link']; ?>"><button type="button" class="btn btn-success w-100" style="width: 130px!important">จัดการเกม</button></a>                         
                                <button type="button" class="btn btn-warning w-100 mb-1 mt-2" style="width: 130px!important" data-bs-toggle="modal" id="insert_btn" data-bs-target="#editModal<?= $cate['id']; ?>">
                                    <i class="fa-regular fa-pen-to-square"></i> แก้ไข
                                </button> 
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php foreach ($cate_topupgame as $row) : ?>
    <div class="modal fade" id="editModal<?= $row['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                        <i class="fa-regular fa-circle-question"></i> <?= $row['name']; ?>
                    </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="col-lg-12 m-cent ">
                        <div class="mb-2">
                            <p class="mb-1 text-white">ชื่อ <span class="text-danger">*</span></p>
                            <input type="text" id="name<?= $row['id']; ?>" class="form-control" value="<?= $row['name']; ?>">
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">รูป <span class="text-danger">*</span></p>
                            <input type="text" id="img<?= $row['id']; ?>" class="form-control" value="<?= $row['img']; ?>">
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">ลิ้งค์ <span class="text-danger">*</span></p>
                            <input type="text" id="link<?= $row['id']; ?>" class="form-control" value="<?= $row['link']; ?>">
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">รายละเอียด <span class="text-danger">*</span></p>
                            <textarea type="text" class="form-control" id="des<?= $row['id']; ?>"><?= $row['des']; ?></textarea>
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">สถานะ<span class="text-danger">*</span></p>
                            <select class="form-select" id="status<?= $row['id']; ?>">
                                <option value="เปิด" <?php if ($row['status'] == "เปิด") echo "selected"; ?>>เปิด</option>
                                <option value="ปิด" <?php if ($row['status'] == "ปิด") echo "selected"; ?>>ปิด</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-success" onclick="edit_topup_game(<?= $row['id']; ?>, $('#name<?= $row['id']; ?>').val(), $('#img<?= $row['id']; ?>').val(), $('#link<?= $row['id']; ?>').val(), $('#des<?= $row['id']; ?>').val(), $('#status<?= $row['id']; ?>').val());">
                        <i class="fa-solid fa-pen-to-square"></i> แก้ไข
                    </button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                        <i class="fa-solid fa-circle-xmark"></i> ปิดหน้าต่างนี้
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<script>
    function edit_topup_game(id, name, img, link, des, status) {
        var formData = new FormData();
        formData.append('id', id);
        formData.append('name', name);
        formData.append('img', img);
        formData.append('link', link);
        formData.append('des', des);
        formData.append('status', status);
        formData.append('table', "category_topupgame");

        $.ajax({
            type: 'POST',
            url: '/systems/edit_categame.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({
                icon: 'success',
                title: 'สำเร็จ',
                text: res.message
            }).then(function () {
                window.location = "?page=<?php echo $_GET['page'];?>";
            });
        }).fail(function (jqXHR) {
            console.log(jqXHR);
            res = jqXHR.responseJSON;
            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: res.message
            });
        });
    }
</script>
<script>
    $('#history_buy1').dataTable({
        "order": [
            [0, 'desc']
        ],
        "columnDefs": [{
            "className": "dt-center text-white", // เพิ่ม class text-white ที่นี่
            "targets": "_all"
        }],
        "oLanguage": {
            "sLengthMenu": "แสดง _MENU_ เร็คคอร์ด ต่อหน้า",
            "sZeroRecords": "ไม่เจอข้อมูลที่ค้นหา",
            "sInfo": "แสดง _START_ ถึง _END_ ของ _TOTAL_ เร็คคอร์ด",
            "sInfoEmpty": "แสดง 0 ถึง 0 ของ 0 เร็คคอร์ด",
            "sInfoFiltered": "(จากเร็คคอร์ดทั้งหมด _MAX_ เร็คคอร์ด)",
            "sSearch": "ค้นหา :",
            "aaSorting": [
                [0, 'asc']
            ],
            "oPaginate": {
                "sFirst": "หน้าแรก",
                "sPrevious": "ก่อนหน้า",
                "sNext": "ถัดไป",
                "sLast": "หน้าสุดท้าย"
            },
        }
    });
</script>