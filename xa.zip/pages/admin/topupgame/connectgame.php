<?php
$thxk = new member;
$acckt = $thxk->acckt();
?>
<div class="container-fluid mt-2 p-0">
    <?php include 'layouts/nav_admin.php'; ?>
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center"><i class="fa-solid fa-folder-gear fa-xl" style="color: #ffffff;"></i> เชื่อมต่อแอคเค้าท์ ( ขั้นเทพ ) และ เชื่อมต่อโทเค่น ( ไอพลาสวิว )</h3>
        </div>
        <div class="class-thxk p-4 mb-3" data-aos="zoom-in">
            <div class="container-fluid btn btn-dark p-3 mb-3" style="border-radius: 1vh;">
                <a id="submit_acckt" style="text-decoration: none;">
                    <center>
                        <i class="fa-sharp fa-solid fa-floppy-disk fa-xl" style="color: #ffffff;"></i>
                        <h5 class="ms-1 mb-0">บันทึกการตั้งค่า</h5>
                    </center>
                </a>
            </div>
            <div class="col-lg-12 m-cent">
                <div class="text-center" style="font-size:24px;">

                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-2">
                        <p class="mb-1">USERNAME <a href="https://www.khanthep.in.th/"><span class="text-danger">* (KHANTHEP.IN.TH)</span></a></p>
                        <input type="text" id="username" class="form-control" value="<?php echo $acckt['username'] ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-2">
                        <p class="mb-1">PASSWORD <a href="https://www.khanthep.in.th/"><span class="text-danger">* (KHANTHEP.IN.TH)</span></a></p>
                        <input type="text" id="password" class="form-control" value="<?php echo $acckt['password'] ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-2">
                        <p class="mb-1">TOKEN <a href="https://iplusview.store/"><span class="text-danger">* (IPLUSVIEW.STORE)</span></a></p>
                        <input type="text" id="token" class="form-control" value="<?php echo $acckt['token'] ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$("#submit_acckt").click(function () {
    var username = $("#username").val();
    var password = $("#password").val();
    var token = $("#token").val();
    $.ajax({
        type: "POST",
        url: "../systems/acckt.php",
        dataType: "json",
        data: { username, password, token },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})
</script>