<?php
$thxk = new member;
$topup_freefire = $thxk->topup_freefire();
?>
<style>
    .modal-content {
        background: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(5px);
        border: none;
        color: #fff;
        border-radius: 1vw;
        padding: 20px;
        box-shadow: 2px rgba(11, 11, 11, 0.3);
    }
</style>
<div class="container-fluid mt-2 p-0">
<?php include 'layouts/nav_admin.php'; ?>
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-3 mt-4 mb-3" data-aos="zoom-in" data-aos="700">
            <center>
                <h4>จัดการเกม FreeFire</h4>
                <hr>
            </center>
            <div class="table-responsive">
                <table id="history_buy1" class="table table-striped table-dark text-center" style="width:100%">
                    <thead>
                        <tr>
                            <th>ไอดี</th>
                            <th width="23%">สินค้า</th>
                            <th width="10%">รวม</th>
                            <th>ราคา</th>
                            <th width="15%">เลขไอดี</th>
                            <th width="15%">สถานะ</th>
                            <th width="15%">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($topup_freefire as $f) : ?>
                        <tr>
                            <td><?= $f['id'] ?></td>
                            <td><?= $f['name'] ?></td>
                            <td><?= $f['diamond'] ?></td>
                            <td><?= $f['amount'] ?></td>
                            <td><?= $f['number'] ?></td>
                            <td>
                                <?php if ($f['status'] == 'เปิดขาย') {?>
                                    <span class="badge text-bg-success">เปิดขาย</span>
                                <?php } elseif($f['status'] == 'ปิดขาย' )  {?>
                                    <span class="badge text-bg-danger">ปิดขาย</span>
                                <?php } ?>
                            </td>
                            <td>                       
                                <button type="button" class="btn btn-warning w-100 mb-1" style="width: 130px!important" data-bs-toggle="modal" id="insert_btn" data-bs-target="#editShopModal<?= $f['id']; ?>">
                                    <i class="fa-regular fa-pen-to-square"></i> แก้ไข
                                </button> 
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php foreach ($topup_freefire as $row) : ?>
    <div class="modal fade" id="editShopModal<?= $row['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">
                        <i class="fa-regular fa-circle-question"></i> ข้อมูลชื่อ <?= $row['name']; ?>
                    </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="col-lg-12 m-cent ">
                        <div class="mb-2">
                            <p class="mb-1 text-white">ราคา <span class="text-danger">*</span></p>
                            <input type="text" id="name<?= $row['id']; ?>" class="form-control" value="<?= $row['name']; ?>">
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">ราคา <span class="text-danger">*</span></p>
                            <input type="text" id="price<?= $row['id']; ?>" class="form-control" value="<?= $row['amount']; ?>">
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">หมายเลข <span class="text-danger">*</span></p>
                            <input type="text" class="form-control" disabled placeholder="number" id="number<?= $row['id']; ?>" value="<?= $row['number']; ?>">
                        </div>
                        <div class="mb-2">
                            <p class="mb-1 text-white">สถานะสินค้า<span class="text-danger">*</span></p>
                            <select class="form-select" id="status<?= $row['id']; ?>">
                                <option value="เปิดขาย" <?php if ($row['status'] == "เปิดขาย") echo "selected"; ?>>เปิดขาย</option>
                                <option value="ปิดขาย" <?php if ($row['status'] == "ปิดขาย") echo "selected"; ?>>ปิดขาย</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-success" onclick="edit_topup_game(<?= $row['id']; ?>, $('#name<?= $row['id']; ?>').val(), $('#price<?= $row['id']; ?>').val(), $('#number<?= $row['id']; ?>').val(), $('#status<?= $row['id']; ?>').val());">
                        <i class="fa-solid fa-pen-to-square"></i> แก้ไข
                    </button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                        <i class="fa-solid fa-circle-xmark"></i> ปิดหน้าต่างนี้
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<script>
    function edit_topup_game(id, name, price, number, status) {
        var formData = new FormData();
        formData.append('id', id);
        formData.append('name', name);
        formData.append('price', price);
        formData.append('number', number);
        formData.append('status', status);
        formData.append('table', "freefire");

        $.ajax({
            type: 'POST',
            url: '/systems/edit_game.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            Swal.fire({
                icon: 'success',
                title: 'สำเร็จ',
                text: res.message
            }).then(function () {
                window.location = "?page=<?php echo $_GET['page'];?>";
            });
        }).fail(function (jqXHR) {
            console.log(jqXHR);
            res = jqXHR.responseJSON;
            Swal.fire({
                icon: 'error',
                title: 'เกิดข้อผิดพลาด',
                text: res.message
            });
        });
    }
</script>
<script>
    $(document).on('click', '[data-bs-toggle="modal"][data-bs-target="#editProductModal"]', function() {
        var id = $(this).data('id');
        var productData = <?php echo json_encode($topup_freefire); ?>;
        var selectedData = productData.find(function(item) {
            return item.id == id;
        });
        if (selectedData) {
            $("#id_product").val(selectedData.id);
            $("#edit_name_product").val(selectedData.name);
            $("#edit_price_product").val(selectedData.diamond);
            $("#edit_details_product").val(selectedData.amount);
            $("#edit_image_product").val(selectedData.number);
            $("#edit_category_product").val(selectedData.status);
        }
    });
</script>
