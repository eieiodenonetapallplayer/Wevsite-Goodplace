<div class="container-fluid mt-2 p-0">
    <?php include 'layouts/nav_admin.php'; ?>
    <div class="container p-4 pt-0 pb-0 m-cent">
        <div class="class-thxk p-4 mt-3 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-solid fa-folder-gear fa-xl" style="color: #ffffff;"></i> ระบบจัดการหลังบ้าน</h3>
        </div>
        <div class="row">
            <!-- คอลัมน์แรก -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/webconfig" style="text-decoration: none;">
                        <center>
                            <i class="fa-sharp fa-solid fa-file-pen fa-xl" style="color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">แก้ไขเว็บไซต์</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัม์สอง -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/slide" style="text-decoration: none;">
                        <center>
                            <i class="fa-light fa-image fa-xl" style="color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">แก้ไขภาพสไลด์</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัมน์ที่สาม -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/manage_users" style="text-decoration: none;">
                        <center>
                            <i class="fa-solid fa-users fa-xl" style="color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">จัดการผู้ใช้งาน</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัมน์ที่สี่ -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/history_topup" style="text-decoration: none;">
                        <center>
                            <i class="fa-sharp fa-solid fa-list-check fa-xl" style="color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">ประวัติการเติมเงิน</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัมน์ที่ห้า -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/history_buy" style="text-decoration: none;">
                        <center>
                            <i class="fa-sharp fa-regular fa-files fa-xl" style="color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">ประวัติการซื้อสินค้า</h5>
                        </center>
                    </a>
                </div>
            </div>
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/history_app" style="text-decoration: none;">
                        <center>
                            <i class="fa-sharp fa-regular fa-files fa-xl" style="color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">ประวัติการซื้อแอพสตรีมมิ่ง</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัมน์ที่หก -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/topup_config" style="text-decoration: none;">
                        <center>
                            <i class="fa-duotone fa-gear fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">ตั้งค่าระบบเติมเงิน</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัมน์ที่แปด -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/byshopme" style="text-decoration: none;">
                        <center>
                            <i class="fa-duotone fa-link-simple fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">ตั้งค่าระบบ API</h5>
                        </center>
                    </a>
                </div>
            </div>
            <!-- คอลัมน์ที่เก้า -->
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/setting_notify" style="text-decoration: none;">
                        <center>
                            <i class="fa-sharp fa-solid fa-bell fa-xl"></i><br><br>
                            <h5 class=" ms-1 mb-0">ตั้งค่าระบบแจ้งเตือน</h5>
                        </center>
                    </a>
                </div>
            </div>
        </div>
        <div class="class-thxk p-4 mt-1 mb-3">
            <h3 class="text-center text-thxk"><i class="fa-solid fa-folder-gear fa-xl" style="color: #ffffff;"></i> จัดการะบบสต็อกสินค้า</h3>
        </div>
        <div class="row">
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/product_category" style="text-decoration: none;">
                        <center>
                        <i class="fa-duotone fa-layer-group fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">จัดการหมวดหมู่สินค้า</h5>
                        </center>
                    </a>
                </div>
            </div>
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/product_stock" style="text-decoration: none;">
                        <center>
                            <i class="fa-duotone fa-cart-shopping fa-xl" style="--fa-primary-color: #ffffff; --fa-secondary-color: #ffffff;"></i><br><br>
                            <h5 class=" ms-1 mb-0">จัดการระบบสต็อกสินค้า</h5>
                        </center>
                    </a>
                </div>
            </div>
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/productbyshopme" style="text-decoration: none;">
                        <center>
                        <i class="fa-duotone fa-signal-bars-good fa-xl"></i><br><br>
                            <h5 class=" ms-1 mb-0">จัดการระบบสินค้า API</h5>
                        </center>
                    </a>
                </div>
            </div>
            <div class="col-md-3 text-center mb-3">
                <div class="container-fluid class-menu p-4">
                    <a href="/admin/contact_config" style="text-decoration: none;">
                        <center>
                            <i class="fa-sharp fa-solid fa-id-card fa-xl"></i><br><br>
                            <h5 class=" ms-1 mb-0">ตั้งค่าช่องทางการติดต่อ</h5>
                        </center>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>