<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
?>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAdmin" aria-controls="navbarNavAdmin" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNavAdmin">
            <ul class="navbar-nav text-center">
                <?php if ($resultuser['rank'] == 1) { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/webconfig"><i class="fa-duotone fa-cog"></i> จัดการเว็บไซต์</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/slide"><i class="fa-duotone fa-cog"></i> จัดการรูปสไลด์</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/manage_users"><i class="fa-duotone fa-cog"></i> จัดการผู้ใช้งาน</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/history_topup"><i class="fa-duotone fa-cog"></i> ประวัติการเติมเงิน</a>
                    </li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cog"></i> ประวัติการซื้อสินค้า
                        </a>
                        <div class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/admin/history_buy"><span><i class="fa-duotone fa-cog"></i> ประวัติการซื้อสินค้า</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/history_app"><span><i class="fa-duotone fa-cog"></i> ประวัติการซื้อแอพสตรีมมิ่ง</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/history_social"><span><i class="fa-duotone fa-cog"></i> ประวัติการปั้มโซเชียล</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/history_topupgame"><span><i class="fa-duotone fa-cog"></i> ประวัติการเติมเกม</span></a>
                        </div>
                    </li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cog"></i> จัดการบริการอื่นๆ
                        </a>
                        <div class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/admin/connectgameorsocial"><span><i class="fa-duotone fa-cog"></i> เชื่อมแอคเค้าท์และโทเค่น</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/topupgamemanager"><span><i class="fa-duotone fa-cog"></i> จัดการเกม</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/socialmanager"><span><i class="fa-duotone fa-cog"></i> จัดการปั้มโซเชียล</span></a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/topup_config"><i class="fa-duotone fa-cog"></i> จัดการระบบเติมเงิน</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cog"></i> จัดการสินค้า
                        </a>
                        <div class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/admin/product_category"><span><i class="fa-duotone fa-cog"></i> จัดการหมวดหมู่สินค้า</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/product_stock"><span><i class="fa-duotone fa-cog"></i> จัดการสินค้าแบบสต็อก</span></a>
                            <a class="dropdown-item bg-dark" href="/admin/productbyshopme"><span><i class="fa-duotone fa-cog"></i> จัดการสินค้าแบบ API</span></a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/service_manager"><i class="fa-duotone fa-cog"></i> จัดการบริการไอดีพาส</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/byshopme"><i class="fa-duotone fa-cog"></i> จัดการ API</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/setting_notify"><i class="fa-duotone fa-cog"></i> จัดการแจ้งเตือน</a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>