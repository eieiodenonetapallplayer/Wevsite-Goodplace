<?php
$thxk = new member;
$resultuser = $thxk->resultuser();
?>
<?php 
  $sv = dd_q("SELECT * FROM service_setting")->fetch(PDO::FETCH_ASSOC);
  $sv_status = $sv["status"]; 
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-nav">
    <div class="container">
        <a class="navbar-brand" href="/home">
            <img src="<?php echo $webconfig['logo']; ?>" height="65" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav ms-auto text-center gap-3">
                <?php if (empty($_SESSION['id'])) { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/home"><i class="fa-duotone fa-house fa-beat"></i> หน้าหลัก</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cart-shopping fa-beat"></i> ร้านค้า
                        </a>
                        <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/shoping"><span><i class="fa-duotone fa-gamepad-modern"></i> ร้านค้า</span></a>
                            <?php if ($sv_status == "on") : ?>
                            <a class="dropdown-item bg-dark" href="/service"><span><i class="fa-duotone fa-thumbs-up"></i> บริการไอดีพาส</span></a>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cart-shopping fa-beat"></i> บริการอื่นๆ
                        </a>
                        <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/topupgame"><span><i class="fa-duotone fa-gamepad-modern"></i> เติมเกม</span></a>
                            <a class="dropdown-item bg-dark" href="/socialbooster"><span><i class="fa-duotone fa-thumbs-up"></i> ปั้มโชเชียล</span></a>
                            <a class="dropdown-item bg-dark" href="/app"><span><i class="fa-duotone fa-signal-stream fa-beat"></i> สตรีมมิ่ง</span></a>
                        </ul>
                    </li>
                        
                    <li class="nav-item">
                        <a class="nav-link" href="/login"><i class="fa-duotone fa-right-to-bracket"></i> เข้าสู่ระบบ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/register"><i class="fa-solid fa-user-plus"></i> สมัครสมาชิก</a>
                    </li>
                <?php } else { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="/home"><i class="fa-duotone fa-house fa-beat"></i> หน้าหลัก</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cart-shopping fa-beat"></i> ร้านค้า
                        </a>
                        <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/shoping"><span><i class="fa-duotone fa-gamepad-modern"></i> ร้านค้า</span></a>
                            <?php if ($sv_status == "on") : ?>
                            <a class="dropdown-item bg-dark" href="/service"><span><i class="fa-duotone fa-thumbs-up"></i> บริการไอดีพาส</span></a>
                            <?php endif; ?>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="/app"><i class="fa-duotone fa-signal-stream fa-beat"></i> สตรีมมิ่ง</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-cart-shopping fa-beat"></i> บริการอื่นๆ
                        </a>
                        <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/topupgame"><span><i class="fa-duotone fa-gamepad-modern"></i> เติมเกม</span></a>
                            <a class="dropdown-item bg-dark" href="/socialbooster"><span><i class="fa-duotone fa-thumbs-up"></i> ปั้มโชเชียล</span></a>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/topup"><i class="fa-duotone fa-wallet fa-beat"></i> เติมเงิน</a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa-duotone fa-clock-rotate-left fa-beat"></i> ประวัติการซื้อ
                        </a>
                        <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark" href="/historybuy"><span><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติการซื้อสินค้า</span></a>
                            <a class="dropdown-item bg-dark" href="/historyservice"><span><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติบริการไอดีพาส</span></a>
                            <a class="dropdown-item bg-dark" href="https://old.mreasyshop.xyz/index.php" ><span><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติการซื้อสินค้าเว็บเดิม</span></a>
                            <a class="dropdown-item bg-dark" href="/historyapp"><span><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติการซื้อแอพสตรีมมิ่ง</span></a>
                            <a class="dropdown-item bg-dark" href="/historysocial"><span><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติการปั้มโซเชียล</span></a>
                            <a class="dropdown-item bg-dark" href="/historytopupgame"><span><i class="fa-duotone fa-clock-rotate-left"></i> ประวัติการเติมเกม</span></a>
                        </ul>
                    </li>
                    

                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-uppercase " href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-duotone fa-user-astronaut fa-beat" style="--fa-secondary-opacity: 0.5;"></i> <?php echo strtoupper($resultuser['username']) ?></a>
                        <ul class="dropdown-menu bg-dark" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item bg-dark"><span><i class="fa-duotone fa-wallet"></i> ยอดเงิน <?php echo $resultuser['point'] ?> บาท</span></a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item bg-dark" href="/profile"><span><i class="fa-duotone fa-gear fa-spin"></i> ตั้งค่าบัญชี</span></a>
                            <a class="dropdown-item bg-dark logout" href="#"><span><i class="fa-solid fa-right-from-bracket"></i> ออกจากระบบ</span></a>
                            <?php
                            if ($resultuser['rank'] == 1) {
                                echo '
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item bg-dark" href="/admin/backend"><span><i class="fa-duotone fa-gear"></i> จัดการหลังบ้าน</span></a>';
                            }
                            ?>
                        </ul>
                    </li>
                    
                    
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>
<script src="../js/navbar.js"></script>