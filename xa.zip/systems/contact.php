<?php
include '../config/class.php';
$thxk = new admin;

if (empty($_SESSION['id'])) {
    echo json_encode(array('status' => "error", 'message' => "กรุณาเข้าสู่ระบบ"));
} elseif (empty($_POST['facebook']) || empty($_POST['line']) || empty($_POST['discord'])) {
    echo json_encode(array('status' => "error", 'message' => "กรุณากรอกข้อมูลให้ครบ"));
} else {
    $contact = $thxk->contact($_POST['facebook'], $_POST['line'], $_POST['discord']);
}
