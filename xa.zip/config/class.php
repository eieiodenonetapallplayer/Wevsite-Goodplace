<?php
require 'connect.php';
class member
{
    private $db;
    function __construct()
    {
        $this->db = database();
    }
    public function slide_picture()
    {
        $stmt = $this->db->prepare("SELECT * FROM slide_picture ORDER BY id ASC");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function show_category()
    {
        $stmt = $this->db->prepare("SELECT * FROM product_category");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function card_product()
    {
        $stmt = $this->db->prepare("SELECT * FROM card_product");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function socialservice()
    {
        $stmt = $this->db->prepare("SELECT * FROM socialservice");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function cate_topupgame()
    {
        $stmt = $this->db->prepare("SELECT * FROM category_topupgame");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function cate_topupgames()
    {
        $stmt = $this->db->prepare("SELECT * FROM category_topupgame WHERE status = 'เปิด'");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    public function service()
    {
        $stmt = $this->db->prepare("SELECT * FROM service_cate");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    public function topup_freefire()
    {
        $stmt = $this->db->prepare("SELECT * FROM freefire");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_honkai()
    {
        $stmt = $this->db->prepare("SELECT * FROM honkai");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_fcmobile()
    {
        $stmt = $this->db->prepare("SELECT * FROM fcmoblie");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_valorant()
    {
        $stmt = $this->db->prepare("SELECT * FROM valorant");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_pubggb()
    {
        $stmt = $this->db->prepare("SELECT * FROM pubg");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_genshinimpact()
    {
        $stmt = $this->db->prepare("SELECT * FROM genshinimpact");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_arenabreakout()
    {
        $stmt = $this->db->prepare("SELECT * FROM arenabreakout");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_aceracer()
    {
        $stmt = $this->db->prepare("SELECT * FROM aceracer");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_xhero()
    {
        $stmt = $this->db->prepare("SELECT * FROM xhero");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_zepeto()
    {
        $stmt = $this->db->prepare("SELECT * FROM zepeto");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_lolriot()
    {
        $stmt = $this->db->prepare("SELECT * FROM lolriot");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_ragnarok()
    {
        $stmt = $this->db->prepare("SELECT * FROM ragnarok");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_sausageman()
    {
        $stmt = $this->db->prepare("SELECT * FROM sausageman");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_dragonraja()
    {
        $stmt = $this->db->prepare("SELECT * FROM dragonraja");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_muorigin3()
    {
        $stmt = $this->db->prepare("SELECT * FROM muorigin3");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function topup_identityv()
    {
        $stmt = $this->db->prepare("SELECT * FROM identityv");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    public function history_buy()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_shop ORDER BY date DESC");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    public function count_member()
    {
        $stmt = $this->db->prepare("SELECT count(id) as total FROM users");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function count_category()
    {
        $stmt = $this->db->prepare("SELECT count(id) as total FROM product_category");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function contact()
    {
        $stmt = $this->db->prepare("SELECT * FROM contact_config WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }

    public function count_product_ready()
    {
        $stmt = $this->db->prepare("SELECT SUM(api_stock) as total FROM products_byshopme");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function product($type)
    {
        $stmt = $this->db->prepare("SELECT * FROM card_product WHERE type = :type");
        $stmt->execute(['type' => $type]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function count_stock_buyed()
    {
        $stmt = $this->db->prepare("SELECT COUNT(id) as total FROM history_shop");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function totalproduct($id_card)
    {
        $stmt = $this->db->prepare("SELECT count(id) as total FROM stock_id WHERE id_card = :id_card AND username_buy = '0'");
        $stmt->execute(['id_card' => $id_card]);
        $result = $stmt->fetch();
        return $result;
    }
    public function users_list()
    {
        $stmt = $this->db->prepare("SELECT * FROM users");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function notify_config()
    {
        $stmt = $this->db->prepare("SELECT * FROM notify_config WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function history_wallet()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_wallet");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function history_verifyslip()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_slip");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }
    public function webconfig()
    {
        $stmt = $this->db->prepare("SELECT * FROM web_config WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function byshopme_api()
    {
        $stmt = $this->db->prepare("SELECT * FROM byshopme WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function acckt()
    {
        $stmt = $this->db->prepare("SELECT * FROM acckt WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function history_shop()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_shop WHERE username = :username");
        $stmt->execute([':username' => $_SESSION['username']]);
        $result = $stmt->fetchAll();
        return $result;
    }
    public function history_service()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_social WHERE username = :username");
        $stmt->execute([':username' => $_SESSION['username']]);
        $result = $stmt->fetchAll();
        return $result;
    }
    public function history_topupgame()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_game WHERE username = :username");
        $stmt->execute([':username' => $_SESSION['username']]);
        $result = $stmt->fetchAll();
        return $result;
    }
    public function all_history_shop()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_shop");
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    public function all_history_social()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_social");
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    public function all_history_topupgame()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_game");
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $result;
    }
    public function topup_config()
    {
        $stmt = $this->db->prepare("SELECT * FROM topup_config WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        return $result;
    }
    public function products_byshopme()
    {
        $stmt = $this->db->prepare("SELECT * FROM products_byshopme");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    public function history_byshopme()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_byshopme");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    public function history_social()
    {
        $stmt = $this->db->prepare("SELECT * FROM history_social");
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function login($username, $password)
    {
        $thxk = new member;
        $notify_config = $thxk->notify_config();
        $dis_login = $notify_config['dis_login'];
        $line_notify = $notify_config['line_login'];

        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        $result = $stmt->fetch();

        if ($stmt->rowCount() > 0) {
            if (password_verify($password, $result['password'])) {
                $_SESSION['id'] = $result['id'];
                $_SESSION['username'] = $result['username'];
                echo json_encode(array('status' => "success", 'message' => "เข้าสู่ระบบสำเร็จ"));

                ////////////////////////////////////////////////////////////
                $displayUsername = substr($username, 0, 2);
                $displayUsername .= str_repeat("*", 4);
                ////////////////////////////////////////////////////////////
                $url = $dis_login;
                $embedData = [
                    [
                        "color" => hexdec("D60000"),
                        "fields" => [
                            [
                                "name" => "📝 Username (ผู้ใช้งาน)",
                                "value" => "➡️ **" . $result['username'] . "**",
                                "inline" => false
                            ],
                            [
                                "name" => "",
                                "value" => "",
                                "inline" => false
                            ],
                            [
                                "name" => "📝 Status (สถานะ)",
                                "value" => "➡️ **เข้าสู่ระบบเรียบร้อยแล้ว**",
                                "inline" => false
                            ],
                        ]
                    ]
                ];
                $this->sendToDiscordWebhook($url, $embedData);
                ////////////////////////////////////////////////////////////
                $lineNotifyToken = $line_notify; // ใส่ Token ของ Line Notify ที่คุณได้รับ
                $lineNotifyMessage = "\nสวัสดี! ผู้ใช้งาน : $displayUsername เข้าสู่ระบบเรียบร้อยแล้ว"; // ข้อความที่คุณต้องการแจ้งเตือน
                $this->sendToLineNotify($lineNotifyToken, $lineNotifyMessage);
                ////////////////////////////////////////////////////////////

            } else {
                echo json_encode(array('status' => "error", 'message' => "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"));
            }
        } else {
            echo json_encode(array('status' => "error", 'message' => "ไม่พบชื่อผู้ใช้"));
        }
    }

    public function register($username, $email, $password)
    {
        $thxk = new member;
        $notify_config = $thxk->notify_config();
        $dis_registered = $notify_config['dis_registered'];
        $line_notify = $notify_config['line_registered'];

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username OR email = :email");
        $stmt->execute([':username' => $username, ':email' => $email]);
        if ($stmt->rowCount() > 0) {
            echo json_encode(array('status' => "error", 'message' => "Username หรือ Email มีคนใช้งานไปแล้ว"));
        } else {
            $insert = $this->db->prepare("INSERT INTO users (username, email, password, date) VALUES (:username, :email, :password, CURRENT_TIMESTAMP)");
            try {
                $insert->execute([':username' => $username, ':email' => $email, ':password' => $hashedPassword]);
                $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username");
                $stmt->execute([':username' => $username]);
                $result = $stmt->fetch();
                $_SESSION['id'] = $result['id'];
                $_SESSION['username'] = $result['username'];
                echo json_encode(array('status' => "success", 'message' => "สมัครสมาชิกสำเร็จ"));

                ////////////////////////////////////////////////////////////
                $displayUsername = substr($username, 0, 2);
                $displayUsername .= str_repeat("*", 4);
                ////////////////////////////////////////////////////////////
                $url = $dis_registered;
                $embedData = [
                    [
                        "color" => hexdec("D60000"),
                        "fields" => [
                            [
                                "name" => "📝 Username (ผู้ใช้งาน)",
                                "value" => "➡️ **" . $result['username'] . "**",
                                "inline" => false
                            ],
                            [
                                "name" => "",
                                "value" => "",
                                "inline" => false
                            ],
                            [
                                "name" => "📝 Status (สถานะ)",
                                "value" => "➡️ **ยินดีต้อนรับสมาชิกใหม่**",
                                "inline" => false
                            ],
                        ]
                    ]
                ];
                $this->sendToDiscordWebhook($url, $embedData);
                ////////////////////////////////////////////////////////////
                $lineNotifyToken = $line_notify; // ใส่ Token ของ Line Notify ที่คุณได้รับ
                $lineNotifyMessage = "\nยินดีต้อนรับ! ผู้ใช้งาน : $displayUsername ได้สมัครสมาชิกเข้าสู่ระบบเรียบร้อยแล้ว"; // ข้อความที่คุณต้องการแจ้งเตือน
                $this->sendToLineNotify($lineNotifyToken, $lineNotifyMessage);
                ////////////////////////////////////////////////////////////

            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        }
    }
    public function buyproduct($productId, $productPrice)
    {
        $thxk = new member;
        $notify_config = $thxk->notify_config();
        $dis_buy = $notify_config['dis_buy'];
        $line_notify = $notify_config['line_buy'];

        $resultuser = $this->resultuser();
        $userPoint = $resultuser['point'];
        $stmt = $this->db->prepare("SELECT apikey_byshopme FROM byshopme WHERE id = '1'");
        $stmt->execute();
        $result = $stmt->fetch();
        $apikey_byshopme = $result['apikey_byshopme'];
        if (!empty($apikey_byshopme)) {
            if ($userPoint >= $productPrice) {
                // กรณี point พอให้ซื้อสินค้า

                // เตรียมข้อมูลที่จะส่งไป API เพื่อซื้อสินค้า
                $data = array(
                    'id' => $productId,
                    'keyapi' => $apikey_byshopme, // แทนที่ด้วย keyapi จริงที่คุณใช้
                    'username_customer' => $_SESSION['username'], // หรือใช้ $_SESSION['id'] ในกรณีที่ต้องการใช้เป็นเลข id ในการเก็บ
                );

                // ส่งข้อมูลไปยัง API เพื่อซื้อสินค้า
                $url = 'https://byshop.me/api/buy';
                $options = array(
                    'http' => array(
                        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data),
                    ),
                );
                $context = stream_context_create($options);
                $result = file_get_contents($url, false, $context);

                // ตรวจสอบผลลัพธ์จาก API
                $response = json_decode($result, true);
                $message = $response['message'];
                if ($response['status'] == 'success') {
                    // กรณีซื้อสินค้าสำเร็จ
                    $product = $response['name'];
                    $time = $response['time'];

                    $newPoint = $userPoint - $productPrice;

                    // อัปเดตจำนวน point ใหม่ในฐานข้อมูล
                    $stmt = $this->db->prepare("UPDATE users SET point = :point WHERE id = :id");
                    try {
                        $stmt->execute([':point' => $newPoint, ':id' => $_SESSION['id']]);
                        echo json_encode(array('status' => 'success', 'message' => 'ซื้อสินค้าเรียบร้อยแล้ว'));


                        ////////////////////////////////////////////////////////////
                        $url = $dis_buy;
                        $displayUsername = substr($resultuser['username'], 0, 2) . str_repeat("*", 4);
                        $embedData = [
                            [
                                "color" => hexdec("D60000"),
                                "fields" => [
                                    [
                                        "name" => "**📝 Username (ผู้ใช้งาน)**",
                                        "value" => "➡️ " . $displayUsername,
                                        "inline" => false
                                    ],
                                    [
                                        "name" => "**🛒 ได้ซื้อสินค้า**",
                                        "value" => "➡️ " . $product,
                                        "inline" => false
                                    ],
                                    [
                                        "name" => "**💎 สถานะ**",
                                        "value" => "➡️ จัดส่งเรียบร้อย",
                                        "inline" => false
                                    ],
                                    [
                                        "name" => "** ⏰ เมื่อเวลา **",
                                        "value" => "➡️ " . $time,
                                        "inline" => false
                                    ],
                                ]
                            ]
                        ];
                        $this->sendToDiscordWebhook($url, $embedData);
                        ////////////////////////////////////////////////////////////
                        $lineNotifyToken = $line_notify; // ใส่ Token ของ Line Notify ที่คุณได้รับ
                        $lineNotifyMessage = "ผู้ใช้งาน : $displayUsername ได้ซื้อสินค้า $product เรียบร้อยแล้ว เมื่อเวลา : $time";
                        $this->sendToLineNotify($lineNotifyToken, $lineNotifyMessage);
                        ////////////////////////////////////////////////////////////

                    } catch (Exception $e) {
                        echo json_encode(array('status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการอัปเดต point'));
                    }
                } else {
                    // กรณีซื้อสินค้าไม่สำเร็จ
                    echo json_encode(array('status' => 'error', 'message' => $message));
                }
            } else {
                // กรณี point ไม่เพียงพอให้ซื้อสินค้า
                echo json_encode(array('status' => 'error', 'message' => 'ยอดเงินไม่เพียงพอ กรุณาเติมเงิน'));
            }
        } else {
            // API key ว่างเปล่า หรือไม่มีค่า
            echo json_encode(array('status' => 'error', 'message' => 'คีย์ API ไม่ถูกต้อง กรุณาอัปเดต API ก่อนใช้งาน'));
        }
    }

    public function edit_users($id, $password, $email, $point, $rank)
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $resultuser = $this->resultuser();

        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } elseif ($stmt->rowCount() === 1) {
            $updateData = [':id' => $id];
            $updateQuery = "UPDATE users SET ";

            if (!empty($password)) {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $updateQuery .= "password = :password, ";
                $updateData[':password'] = $hashedPassword;
            }

            if (!empty($email)) {
                $updateQuery .= "email = :email, ";
                $updateData[':email'] = $email;
            }
            if (!empty($point)) {
                $updateQuery .= "point = :point, ";
                $updateData[':point'] = $point;
            }

            if (!empty($rank)) {
                if ($rank === "0" || $rank === "1") {
                    $updateQuery .= "rank = :rank, ";
                    $updateData[':rank'] = $rank;
                } else {
                    echo json_encode(array('status' => "error", 'message' => "ระดับยศไม่ถูกต้อง"));
                    return;
                }
            }

            $updateQuery = rtrim($updateQuery, ', ');
            $updateQuery .= " WHERE id = :id";
            $update = $this->db->prepare($updateQuery);

            try {
                $update->execute($updateData);
                echo json_encode(array('status' => "success", 'message' => "แก้ไขข้อมูลเรียบร้อย"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        } else {
            echo json_encode(array('status' => "error", 'message' => "ไม่พบผู้ใช้ด้วย ID ที่ระบุ"));
        }
    }
    public function edit_products($product_code, $product_price, $product_image, $product_sell, $product_status)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $id_picture = $this->products_byshopme();
            if ($id_picture) {
                $insert = $this->db->prepare("UPDATE products_byshopme SET product_price = :product_price, product_image = :product_image, product_sell = :product_sell, product_status = :product_status WHERE product_code = :product_code");
                try {
                    $insert->execute([
                        ':product_price' => $product_price,
                        ':product_image' => $product_image,
                        ':product_sell' => $product_sell,
                        ':product_status' => $product_status,
                        ':product_code' => $product_code
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "อัพเดทสินค้าเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                echo json_encode(array('status' => "error", 'message' => "ไม่พบสินค้าที่ตรงกับรหัสสินค้า: " . $product_code));
            }
        }
    }


    public function password($old_password, $new_password)
    {
        $resultuser = $this->resultuser();
        if (password_verify($old_password, $resultuser['password'])) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $stmt = $this->db->prepare("UPDATE users SET password = :password WHERE id = :id");
            try {
                $stmt->execute([':password' => $hashed_password, ':id' => $_SESSION['id']]);
                echo json_encode(array('status' => "success", 'message' => "เปลี่ยนรหัสผ่านสำเร็จ"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        } else {
            echo json_encode(array('status' => "error", 'message' => "รหัสผ่านเก่าไม่ถูกต้อง"));
        }
    }
    public function product_apibyshop()
    {
        $api_url = 'https://byshop.me/api/product';
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http_status == 200) {
            $data = json_decode($response, true);
            $products = [];
            foreach ($data as $product) {
                $product_code = $product['id'];
                $product_name = $product['name'];
                $product_price = $product['price'];
                $product_info = $product['product_info'];
                $api_stock = $product['stock'];
                $api_status = $product['status'];
                $products[] = [
                    'product_code' => $product_code,
                    'product_name' => $product_name,
                    'product_price' => $product_price,
                    'product_info' => $product_info,
                    'api_stock' => $api_stock,
                    'api_status' => $api_status,
                ];
            }
            foreach ($products as $product) {
                $product_code = $product['product_code'];
                $product_name = $product['product_name'];
                $product_price = $product['product_price'];
                $product_info = $product['product_info'];
                $api_stock = $product['api_stock'];
                $api_status = $product['api_status'];
                $insertproduct = $this->db->prepare("INSERT INTO products_byshopme (product_code, product_name, product_price, product_info, api_stock, api_status)
                VALUES (:product_code, :product_name, :product_price, :product_info, :api_stock, :api_status)
                ON DUPLICATE KEY UPDATE product_name = :product_name, product_price = :product_price, product_info = :product_info, api_stock = :api_stock, api_status = :api_status");

                try {
                    $insertproduct->execute([
                        ':product_code' => $product_code,
                        ':product_name' => $product_name,
                        ':product_price' => $product_price,
                        ':product_info' => $product_info,
                        ':api_stock' => $api_stock,
                        ':api_status' => $api_status,
                    ]);
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        } else {
            echo 'เกิดข้อผิดพลาดในการดึงข้อมูลสินค้า';
        }
    }
    public function sendToDiscordWebhook($webhookUrl, $embedData)
    {
        $data = array('embeds' => $embedData);

        $options = array(
            'http' => array(
                'header' => "Content-type: application/json\r\n",
                'method' => 'POST',
                'content' => json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($webhookUrl, false, $context);
        return $result;
    }

    public function sendToLineNotify($token, $message)
    {
        $lineNotifyUrl = 'https://notify-api.line.me/api/notify';
        $headers = array(
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Bearer ' . $token,
        );
        $data = array('message' => $message);

        $options = array(
            'http' => array(
                'header' => implode("\r\n", $headers),
                'method' => 'POST',
                'content' => http_build_query($data),
            ),
        );

        $context = stream_context_create($options);
        $result = file_get_contents($lineNotifyUrl, false, $context);

        return $result;
    }

    public function resultuser()
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute([':id' => $_SESSION['id']]);
        $result = $stmt->fetch();
        return $result;
    }
}
class admin
{
    private $db;
    function __construct()
    {
        $this->db = database();
    }
    public function link_picture($link_picture)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $insert = $this->db->prepare("INSERT INTO slide_picture (link_picture, date) VALUES (:link_picture, CURRENT_TIMESTAMP)");
            try {
                $insert->execute([':link_picture' => $link_picture]);
                $stmt = $this->db->prepare("SELECT * FROM slide_picture WHERE link_picture = :link_picture");
                $stmt->execute([':link_picture' => $link_picture]);
                $result = $stmt->fetch();
                $result['link_picture'];
                echo json_encode(array('status' => "success", 'message' => "บันทึกรูปภาพสำเร็จ"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        }
    }
    public function byshopme($username_byshopme, $apikey_byshopme)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $stmt = $this->db->prepare("SELECT * FROM byshopme WHERE id = 1");
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result) {
                $update = $this->db->prepare("UPDATE byshopme SET username_byshopme = :username_byshopme, apikey_byshopme = :apikey_byshopme WHERE id = 1");
                try {
                    $update->execute([':username_byshopme' => $username_byshopme, ':apikey_byshopme' => $apikey_byshopme]);
                    echo json_encode(array('status' => "success", 'message' => "อัปเดตระบบ API เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $insert = $this->db->prepare("INSERT INTO byshopme (username_byshopme, apikey_byshopme) VALUES (:username_byshopme, :apikey_byshopme)");
                try {
                    $insert->execute([':username_byshopme' => $username_byshopme, ':apikey_byshopme' => $apikey_byshopme]);
                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่าระบบ API เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }

    public function acckt($username, $password, $token)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $stmt = $this->db->prepare("SELECT * FROM acckt WHERE id = 1");
            $stmt->execute();
            $result = $stmt->fetch();
            if ($result) {
                $update = $this->db->prepare("UPDATE acckt SET username = :username, password = :password, token = :token WHERE id = 1");
                try {
                    $update->execute([':username' => $username, ':password' => $password, ':token' => $token]);
                    echo json_encode(array('status' => "success", 'message' => "อัปเดตระบบ API เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $insert = $this->db->prepare("INSERT INTO acckt (username, password, token) VALUES (:username, :password, :token)");
                try {
                    $insert->execute([':username' => $username, ':password' => $password, ':token' => $token]);
                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่าระบบ API เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }


    public function webconfig($name, $logo_icon, $logo, $background, $description, $keywords, $main_color, $sec_color, $font_color)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $checkExist = $this->db->prepare("SELECT * FROM web_config WHERE id = 1");
            $checkExist->execute();
            $exists = $checkExist->fetch(PDO::FETCH_ASSOC);
            if (!$exists) {
                $insert = $this->db->prepare("INSERT INTO web_config (id, name, logo_icon, logo, background, description, keywords, main_color, sec_color, font_color, date) VALUES (1, :name, :logo_icon, :logo, :background, :description, :keywords, :main_color, :sec_color, :font_color, CURRENT_TIMESTAMP)");

                try {
                    $insert->execute([
                        ':name' => $name,
                        ':logo_icon' => $logo_icon,
                        ':logo' => $logo,
                        ':background' => $background,
                        ':description' => $description,
                        ':keywords' => $keywords,
                        ':main_color' => $main_color,
                        ':sec_color' => $sec_color,
                        ':font_color' => $font_color
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "บันทึกการตั้งค่าเว็บไซต์เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $update = $this->db->prepare("UPDATE web_config SET name = :name, logo_icon = :logo_icon, logo = :logo, background = :background, description = :description, keywords = :keywords, main_color = :main_color, sec_color = :sec_color, font_color = :font_color, date = CURRENT_TIMESTAMP WHERE id = 1");
                try {
                    $update->execute([
                        ':name' => $name,
                        ':logo_icon' => $logo_icon,
                        ':logo' => $logo,
                        ':background' => $background,
                        ':description' => $description,
                        ':keywords' => $keywords,
                        ':main_color' => $main_color,
                        ':sec_color' => $sec_color,
                        ':font_color' => $font_color
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "บันทึกการตั้งค่าเว็บไซต์เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }
    public function topup_wallet($link_wallet)
    {
        $thxk = new member;
        $notify_config = $thxk->notify_config();
        $dis_topup = $notify_config['dis_topup'];
        $line_notify = $notify_config['line_topup'];

        $stmt = $this->db->prepare("SELECT wallet_phone, wallet_fee FROM topup_config WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        $wallet_phone = $result['wallet_phone'];
        $wallet_fee = $result['wallet_fee'];
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://byshop.me/api/truewallet',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => 'phone=' . $wallet_phone . '&gift_link=' . $link_wallet, // ปรับปรุงข้อมูลที่ส่งไปในรูปแบบที่ถูกต้อง
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded'
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        $result = json_decode($response);
        $message = $result->message;
        $status = $result->status;
        if ($status == 'success') {
            $amount = $result->amount;
            $phone = $result->phone;
            if ($wallet_fee === "on") {
                $fee = $amount * 0.023;
                $amount -= $fee;
                $update = $this->db->prepare("UPDATE users SET point = point + :amount, topup = topup + :amount WHERE id = :id");
            } else {
                $update = $this->db->prepare("UPDATE users SET point = point + :amount, topup = topup + :amount WHERE id = :id");
            }
            $inserttopup = $this->db->prepare("INSERT INTO `history_wallet` (`username`, `name`, `amount`, `link`, `date`) VALUES (:username, :name, :amount, :link, CURRENT_TIMESTAMP);");
            try {
                $inserttopup->execute([':username' => $_SESSION['username'], ':name' => $phone, ':amount' => $amount, ':link' => $link_wallet]);
                $update->execute([':amount' => $amount, ':id' => $_SESSION['id']]);
                echo json_encode(array('status' => "success", 'message' => $message, 'amount' => $amount));

                // $webhookUrl = $dis_topup;
                // $discordMessage = "** ผู้ใช้งาน : {$_SESSION['username']} ได้เติมเงินผ่านระบบ TRUEWALLET \n ลิงก์ : $link_wallet ชื่อบัญชี {$phone} * \nจำนวน {$amount} บาท ( สถานะเติมเงิน : สำเร็จแล้ว ) **";
                // $this->sendToDiscordWebhook($webhookUrl, $discordMessage);

                $url = $dis_topup;
                $embedData = [
                    [
                        "color" => hexdec("D60000"),
                        "fields" => [
                            [
                                "name" => "📝 Username (ผู้ใช้งาน)",
                                "value" => "➡️ **" . $_SESSION['username'] . "**",
                                "inline" => false
                            ],
                            [
                                "name" => "",
                                "value" => "",
                                "inline" => false
                            ],
                            [
                                "name" => "📝 เติมเงินเข้าสู่ระบบ",
                                "value" => "➡️ **Truewallet**",
                                "inline" => false
                            ],
                            [
                                "name" => "",
                                "value" => "",
                                "inline" => false
                            ],
                            [
                                "name" => "📝 จำนวนเงิน",
                                "value" => "➡️ ** $amount บาท **",
                                "inline" => false
                            ],
                        ]
                    ]
                ];
                $this->sendToDiscordWebhook($url, $embedData);
                ////////////////////////////////////////////////////////////

                $lineNotifyToken = $line_notify;
                $lineNotifyMessage = "ผู้ใช้งาน : {$_SESSION['username']} ได้เติมเงินผ่านระบบ TRUEWALLET \n ลิงก์ : $link_wallet ชื่อบัญชี {$phone} * \nจำนวน {$amount} บาท ( สถานะเติมเงิน : สำเร็จแล้ว )";
                $this->sendToLineNotify($lineNotifyToken, $lineNotifyMessage);
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        } else {
            echo json_encode(array('status' => 'error', 'message' => $message));
        }
    }
	public function topup_verifyslip($slipverify)
    {
        $thxk = new member;
        $notify_config = $thxk->notify_config();
        $dis_topup = $notify_config['dis_topup'];
        $line_notify = $notify_config['line_topup'];

        $stmt = $this->db->prepare("SELECT client_id, client_secret, client_account FROM topup_config WHERE id = 1");
        $stmt->execute();
        $result = $stmt->fetch();
        $client_id = $result['client_id'];
        $client_secret = $result['client_secret'];
        $client_account = $result['client_account'];

        $clientId = $client_id;
        $clientSecret = $client_secret;

        $ch = curl_init('https://suba.rdcw.co.th/v1/inquiry');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'payload=' . $slipverify);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Basic ' . base64_encode("{$clientId}:{$clientSecret}"),
        ]);

        $response = @json_decode(curl_exec($ch));
        curl_close($ch);

        if ($response) {
            $message = $response->message;
            if ($response->valid === true) {
                // ข้อมูลผู้รับ
                // $receiver = $response->data->receiver;
                $name_recei = $response->data->receiver->displayName;
                // $account_type = $receiver->account->type;
                // $account_value = $receiver->account->value;
                $amount = $response->data->amount;

                // ข้อมูลผู้ส่ง
                $sender = $response->data->sender;
                $customer_name = $sender->displayName;
                $customer_bank = $sender->account->type;
                $customer_accountbank = $sender->account->value;
                if (
                    $name_recei === $client_account
                    // $account_type === 'BANKAC' &&
                    // $account_value === $client_account
                ) {
                    if ($response->isCached === true) { /// ตรวจสอบสลิปที่ใช้ไปแล้ว หรือ โดนตรวจสอบแล้ว
                        echo json_encode(['status' => 'error', 'message' => 'QR สลิปโอนเงินถูกใช้งานไปแล้ว']);
                    } else {
                        $update = $this->db->prepare("UPDATE users SET point = point + :amount, topup = topup + :amount WHERE id = :id");
                        $inserttopup = $this->db->prepare("INSERT INTO `history_slip` (`username`, `customer_name`, `customer_bank`, `customer_accountbank`, `amount`, `date`) VALUES (:username, :customer_name, :customer_bank, :customer_accountbank, :amount, CURRENT_TIMESTAMP);");
                        try {
                            $inserttopup->execute([
                                ':username' => $_SESSION['username'],
                                ':customer_name' => $customer_name,
                                ':customer_bank' => $customer_bank,
                                ':customer_accountbank' => $customer_accountbank,
                                ':amount' => $amount,
                            ]);
                            $update->execute([':amount' => $amount, ':id' => $_SESSION['id']]);
                            echo json_encode(['status' => 'success', 'message' => "บัญชีผู้รับโอนเงินถูกต้อง คุณได้รับเงิน {$amount} บาท ขอบคุณที่ใช้บริการ"]);

                           $url = $dis_topup;
								$embedData = [
								[
									"color" => hexdec("D60000"),
									"fields" => [
								[
										"name" => "📝 Username (ผู้ใช้งาน)",
										"value" => "➡️ **" . $_SESSION['username'] . "**",
										"inline" => false
								],
								[
										"name" => "",
										"value" => "",
										"inline" => false
								],
								[
										"name" => "📝 เติมเงินเข้าสู่ระบบ",
										"value" => "➡️ **Verify Slip**",
										"inline" => false
								],
								[
										"name" => "",
										"value" => "",
										"inline" => false
								],
								[
										"name" => "📝 จำนวนเงิน",
										"value" => "➡️ ** $amount บาท **",
										"inline" => false
								],
									]
								]
							];
							$this->sendToDiscordWebhook($url, $embedData);
                            ////////////////////////////////////////////////////////////
                            $lineNotifyToken = $line_notify; // ใส่ Token ของ Line Notify ที่คุณได้รับ
                            $lineNotifyMessage = " ผู้ใช้งาน : {$_SESSION['username']} ได้เติมเงินผ่านระบบตรวจสอบสลิปธนาคาร \n ชื่อบัญชี : {$customer_name} เลขบัญชี : {$customer_accountbank} \n จำนวน {$amount} บาท ( สถานะเติมเงิน : สำเร็จแล้ว ) ";
                            $this->sendToLineNotify($lineNotifyToken, $lineNotifyMessage);
                            ////////////////////////////////////////////////////////////
                        } catch (Exception $e) {
                            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
                        }
                    }
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'บัญชีผู้รับเงินไม่ตรงกับระบบ กรุณาทำรายการใหม่']);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => $message]);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'เกิดข้อผิดพลาดในการส่งคำร้องขอ']);
        }
    }
    public function setting_rdcw($client_id, $client_secret)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $checkExist = $this->db->prepare("SELECT * FROM setting_rdcw WHERE id = 1");
            $checkExist->execute();
            $exists = $checkExist->fetch(PDO::FETCH_ASSOC);
            if (!$exists) {
                $insert = $this->db->prepare("INSERT INTO setting_rdcw (id, client_id, client_secret) VALUES (1, :client_id, :client_secret)");

                try {
                    $insert->execute([
                        ':client_id' => $client_id,
                        ':client_secret' => $client_secret,
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่า SLIP RDCW เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $update = $this->db->prepare("UPDATE setting_rdcw SET client_id = :client_id, client_secret = :client_secret WHERE id = 1");
                try {
                    $update->execute([
                        ':client_id' => $client_id,
                        ':client_secret' => $client_secret,
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่า SLIP RDCW เรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }
    public function topup_config($wallet_phone, $wallet_fee, $name_account, $name_bank, $number_bank, $client_id, $client_secret, $client_account)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $checkExist = $this->db->prepare("SELECT * FROM topup_config WHERE id = 1");
            $checkExist->execute();
            $exists = $checkExist->fetch(PDO::FETCH_ASSOC);
            if (!$exists) {
                $insert = $this->db->prepare("INSERT INTO topup_config (id, wallet_phone, wallet_fee, name_account, name_bank, number_bank, client_id, client_secret, client_account) VALUES (1, :wallet_phone, :wallet_fee, :name_account, :name_bank, :number_bank, :client_id, :client_secret, :client_account)");

                try {
                    $insert->execute([
                        ':wallet_phone' => $wallet_phone,
                        ':wallet_fee' => $wallet_fee,
                        ':name_account' => $name_account,
                        ':name_bank' => $name_bank,
                        ':number_bank' => $number_bank,
                        ':client_id' => $client_id,
                        ':client_secret' => $client_secret,
                        ':client_account' => $client_account,
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่าระบบเติมเงินเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $update = $this->db->prepare("UPDATE topup_config SET wallet_phone = :wallet_phone, wallet_fee = :wallet_fee, name_account = :name_account, name_bank = :name_bank, number_bank = :number_bank, client_id = :client_id, client_secret = :client_secret, client_account = :client_account WHERE id = 1");
                try {
                    $update->execute([
                        ':wallet_phone' => $wallet_phone,
                        ':wallet_fee' => $wallet_fee,
                        ':name_account' => $name_account,
                        ':name_bank' => $name_bank,
                        ':number_bank' => $number_bank,
                        ':client_id' => $client_id,
                        ':client_secret' => $client_secret,
                        ':client_account' => $client_account,
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่าระบบเติมเงินเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }
    public function setting_notify($dis_registered, $dis_login, $dis_topup, $dis_buy, $dis_system, $line_registered, $line_login, $line_topup, $line_buy, $line_system)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $checkExist = $this->db->prepare("SELECT * FROM notify_config WHERE id = 1");
            $checkExist->execute();
            $exists = $checkExist->fetch(PDO::FETCH_ASSOC);
            if (!$exists) {
                $insert = $this->db->prepare("INSERT INTO notify_config (id, dis_registered, dis_login, dis_topup, dis_buy, dis_system, line_registered, line_login, line_topup, line_buy, line_system) VALUES (1, :dis_registered, :dis_login, :dis_topup, :dis_buy, :dis_system , :line_registered, :line_login, :line_topup, :line_buy, :line_system)");

                try {
                    $insert->bindParam(':dis_registered', $dis_registered);
                    $insert->bindParam(':dis_login', $dis_login);
                    $insert->bindParam(':dis_topup', $dis_topup);
                    $insert->bindParam(':dis_buy', $dis_buy);
                    $insert->bindParam(':dis_system', $dis_system);
                    $insert->bindParam(':line_registered', $line_registered);
                    $insert->bindParam(':line_login', $line_login);
                    $insert->bindParam(':line_topup', $line_topup);
                    $insert->bindParam(':line_buy', $line_buy);
                    $insert->bindParam(':line_system', $line_system);


                    $insert->execute();

                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่าระบบแจ้งเตือนเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $update = $this->db->prepare("UPDATE notify_config SET dis_registered = :dis_registered, dis_login = :dis_login, dis_topup = :dis_topup, dis_buy = :dis_buy, dis_system = :dis_system, line_registered = :line_registered, line_login = :line_login, line_topup = :line_topup, line_buy = :line_buy, line_system = :line_system WHERE id = 1");

                try {
                    $update->bindParam(':dis_registered', $dis_registered);
                    $update->bindParam(':dis_login', $dis_login);
                    $update->bindParam(':dis_topup', $dis_topup);
                    $update->bindParam(':dis_buy', $dis_buy);
                    $update->bindParam(':dis_system', $dis_system);
                    $update->bindParam(':line_registered', $line_registered);
                    $update->bindParam(':line_login', $line_login);
                    $update->bindParam(':line_topup', $line_topup);
                    $update->bindParam(':line_buy', $line_buy);
                    $update->bindParam(':line_system', $line_system);

                    $update->execute();

                    echo json_encode(array('status' => "success", 'message' => "ตั้งค่าระบบแจ้งเตือนเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }
    public function buyproduct_stock($id_card)
    {
        $thxk = new member;
        $notify_config = $thxk->notify_config();
        $dis_buy = $notify_config['dis_buy'];
        $line_notify = $notify_config['line_buy'];

        $resultuser = $this->resultuser();
        $card = $this->db->prepare("SELECT * FROM card_product WHERE id = :id");
        $card->execute([':id' => $id_card]);
        $resultcard = $card->fetch();

        $stmtstock = $this->db->prepare("SELECT count(id) as total FROM stock_id WHERE id_card = :id_card AND username_buy = '0'");
        $stmtstock->execute(['id_card' => $id_card]);
        $resultstock = $stmtstock->fetch();

        if ($resultstock['total'] == 0) {
            echo json_encode(array('status' => "error", 'message' => "สินค้าจำหน่ายหมดแล้ว"));
        } else {
            if ($resultuser['point'] < $resultcard['price_product']) {
                echo json_encode(array('status' => "error", 'message' => "ยอดเงินไม่เพียงพอ กรุณาเติมเงิน"));
            } else {
                $stmt = $this->db->prepare("SELECT * FROM stock_id WHERE id_card = :id_card AND username_buy = '0' LIMIT 1");
                $stmt->execute([':id_card' => $id_card]);
                $result = $stmt->fetch();
                $updatepoint = $this->db->prepare("UPDATE `users` SET `point`= point - :point WHERE id = :id");
                $history_shop = $this->db->prepare("INSERT INTO `history_shop` (`username`, `name`, `details`, `price`, `date`) VALUES (:username, :name, :details, :price, CURRENT_TIMESTAMP);");
                $updatestock = $this->db->prepare("UPDATE `stock_id` SET `username_buy`= :username_buy WHERE id = :id");
                try {
                    $updatepoint->execute([':point' => $resultcard['price_product'], ':id' => $_SESSION['id']]);
                    $history_shop->execute([
                        ':username' => $_SESSION['username'],
                        ':name' => $resultcard['name_product'],
                        ':details' => $result['details'],
                        ':price' => $resultcard['price_product'],
                    ]);
                    $updatestock->execute([':username_buy' => $_SESSION['username'], ':id' => $result['id']]);
                    echo json_encode(array('status' => "success", 'message' => "ซื้อสินค้าเรียบร้อยแล้ว"));

                    ////////////////////////////////////////////////////////////
                    $url = $dis_buy;
                    $displayUsername = substr($resultuser['username'], 0, 2) . str_repeat("*", 4);
                    $embedData = [
                        [
                            "color" => hexdec("D60000"),
                            "fields" => [
                                [
                                    "name" => "**📝 Username (ผู้ใช้งาน)**",
                                    "value" => "➡️ " . $displayUsername,
                                    "inline" => false
                                ],
                                [
                                    "name" => "**🛒 ได้ซื้อสินค้า**",
                                    "value" => "➡️ " . $resultcard['name_product'],
                                    "inline" => false
                                ],
                                [
                                    "name" => "**💎 สถานะ**",
                                    "value" => "➡️ จัดส่งเรียบร้อย",
                                    "inline" => false
                                ],
                            ]
                        ]
                    ];
                    $this->sendToDiscordWebhook($url, $embedData);
                    ////////////////////////////////////////////////////////////
                    $lineNotifyToken = $line_notify; // ใส่ Token ของ Line Notify ที่คุณได้รับ
                    $lineNotifyMessage = "ผู้ใช้งาน : {$_SESSION['username']} ได้ซื้อสินค้า {$resultcard['name_product']} เรียบร้อยแล้ว";
                    $this->sendToLineNotify($lineNotifyToken, $lineNotifyMessage);
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getmessage()));
                }
            }
        }
    }
    public function del_product_id($id_picture)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $del_link_picture = $this->db->prepare("DELETE FROM `card_product` WHERE id = :id");
            $del_link_picture->execute([':id' => $id_picture]);
            echo json_encode(array('status' => "success", 'message' => "ลบสินค้าออกจากระบบแล้ว"));
        }
    }
    public function del_service_id($id_del)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $del_link_picture = $this->db->prepare("DELETE FROM `socialservice` WHERE id = :id");
            $del_link_picture->execute([':id' => $id_del]);
            echo json_encode(array('status' => "success", 'message' => "ลบสินค้าออกจากระบบแล้ว"));
        }
    }

    public function del_stock_id($id_stock)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $del_link_picture = $this->db->prepare("DELETE FROM `stock_id` WHERE id = :id");
            $del_link_picture->execute([':id' => $id_stock]);
            echo json_encode(array('status' => "success", 'message' => "ลบสต็อกสินค้าออกจากระบบแล้ว"));
        }
    }
    public function add_product($name_product, $price_product, $details_product, $image_product)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $insert = $this->db->prepare("INSERT INTO card_product (name_product, price_product, details_product, image_product) VALUES (:name_product, :price_product, :details_product, :image_product)");
            try {
                $insert->execute([
                    ':name_product' => $name_product,
                    ':price_product' => $price_product,
                    ':details_product' => $details_product,
                    ':image_product' => $image_product
                ]);
                echo json_encode(array('status' => "success", 'message' => "เพิ่มสินค้าเรียบร้อยแล้ว"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        }
    }
    public function add_service($idapi, $name, $des, $price)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $insert = $this->db->prepare("INSERT INTO socialservice (idapi, name, des, price) VALUES (:idapi, :name, :des, :price)");
            try {
                $insert->execute([
                    ':idapi' => $idapi,
                    ':name' => $name,
                    ':des' => $des,
                    ':price' => $price
                ]);
                echo json_encode(array('status' => "success", 'message' => "เพิ่มสินค้าเรียบร้อยแล้ว"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        }
    }
    public function addCategory($name, $details, $img)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $insert = $this->db->prepare("INSERT INTO product_category (name, details, img) VALUES (:name, :details, :img)");
            try {
                $insert->execute([
                    ':name' => $name,
                    ':details' => $details,
                    ':img' => $img,
                ]);
                echo json_encode(array('status' => "success", 'message' => "เพิ่มหมวดหมู่สินค้าเรียบร้อยแล้ว"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        }
    }
    public function delCategory($id)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $del_link_picture = $this->db->prepare("DELETE FROM `product_category` WHERE id = :id");
            $del_link_picture->execute([':id' => $id]);
            echo json_encode(array('status' => "success", 'message' => "หมวดหมู่ถูกลบออกแล้ว"));
        }
    }
    public function edit_product($id_product, $edit_name_product, $edit_price_product, $edit_details_product, $edit_image_product, $edit_category_product)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $stmt = $this->db->prepare("SELECT * FROM card_product WHERE id = :id_product");
            $stmt->execute([':id_product' => $id_product]);
            $existingProduct = $stmt->fetch();

            if ($existingProduct) {
                $update = $this->db->prepare("UPDATE card_product SET type = :edit_category_product, name_product = :edit_name_product, price_product = :edit_price_product, details_product = :edit_details_product, image_product = :edit_image_product WHERE id = :id_product");
                try {
                    $update->execute([
                        ':id_product' => $id_product,
                        ':edit_category_product' => $edit_category_product,
                        ':edit_name_product' => $edit_name_product,
                        ':edit_price_product' => $edit_price_product,
                        ':edit_details_product' => $edit_details_product,
                        ':edit_image_product' => $edit_image_product
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "อัปเดตข้อมูลเรียบร้อยแล้ว"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                echo json_encode(array('status' => "error", 'message' => "ไม่พบข้อมูลที่ต้องการอัปเดต"));
            }
        }
    }
    public function edit_freefiregame($id_product, $edit_name_product, $edit_price_product, $edit_details_product, $edit_image_product, $edit_category_product)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            return json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $stmt = $this->db->prepare("SELECT * FROM freefire WHERE id = :id_product");
            $stmt->execute([':id_product' => $id_product]);
            $existingProduct = $stmt->fetch();

            if ($existingProduct) {
                $update = $this->db->prepare("UPDATE freefire SET name = :edit_category_product, diamond = :edit_name_product, amount = :edit_price_product, number = :edit_details_product, status = :edit_image_product WHERE id = :id_product");
                try {
                    $update->execute([
                        ':id_product' => $id_product,
                        ':edit_category_product' => $edit_category_product,
                        ':edit_name_product' => $edit_name_product,
                        ':edit_price_product' => $edit_price_product,
                        ':edit_details_product' => $edit_details_product,
                        ':edit_image_product' => $edit_image_product
                    ]);
                    return json_encode(array('status' => "success", 'message' => "อัปเดตข้อมูลเรียบร้อยแล้ว"));
                } catch (Exception $e) {
                    return json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                return json_encode(array('status' => "error", 'message' => "ไม่พบข้อมูลที่ต้องการอัปเดต"));
            }
        }
    }
    public function edit_service($edit_id, $edit_idapi, $edit_name, $edit_desss, $edit_price)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $stmt = $this->db->prepare("SELECT * FROM socialservice WHERE id = :edit_id");
            $stmt->execute([':edit_id' => $edit_id]);
            $existingProduct = $stmt->fetch();

            if ($existingProduct) {
                $update = $this->db->prepare("UPDATE socialservice SET idapi = :edit_idapi, name = :edit_name, des = :edit_desss, price = :edit_price WHERE id = :edit_id");
                try {
                    $update->execute([
                        ':edit_id' => $edit_id,
                        ':edit_idapi' => $edit_idapi,
                        ':edit_name' => $edit_name,
                        ':edit_desss' => $edit_desss,
                        ':edit_price' => $edit_price
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "อัปเดตข้อมูลเรียบร้อยแล้ว"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                echo json_encode(array('status' => "error", 'message' => "ไม่พบข้อมูลที่ต้องการอัปเดต"));
            }
        }
    }
    public function edit_catetopupgame($edit_id, $edit_name, $edit_img, $edit_des, $edit_link, $edit_status)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $stmt = $this->db->prepare("SELECT * FROM category_topupgame WHERE id = :edit_id");
            $stmt->execute([':edit_id' => $edit_id]);
            $existingProduct = $stmt->fetch();

            if ($existingProduct) {
                $update = $this->db->prepare("UPDATE category_topupgame SET name = :edit_name, img = :edit_img, des = :edit_des, link = :edit_link, status = :edit_status WHERE id = :edit_id");
                try {
                    $update->execute([
                        ':edit_id' => $edit_id,
                        ':edit_name' => $edit_name,
                        ':edit_img' => $edit_img,
                        ':edit_des' => $edit_des,
                        ':edit_link' => $edit_link,
                        ':edit_status' => $edit_status
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "อัปเดตข้อมูลเรียบร้อยแล้ว"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                echo json_encode(array('status' => "error", 'message' => "ไม่พบข้อมูลที่ต้องการอัปเดต"));
            }
        }
    }

    public function contact($facebook, $line, $discord)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "ไม่ใช่แอดมิน"));
        } else {
            $checkExist = $this->db->prepare("SELECT * FROM contact_config WHERE id = 1");
            $checkExist->execute();
            $exists = $checkExist->fetch(PDO::FETCH_ASSOC);
            if (!$exists) {
                $insert = $this->db->prepare("INSERT INTO contact_config (id, facebook, line, discord, date) VALUES (1, :facebook, :line, :discord, CURRENT_TIMESTAMP)");

                try {
                    $insert->execute([
                        ':facebook' => $facebook,
                        ':line' => $line,
                        ':discord' => $discord,

                    ]);
                    echo json_encode(array('status' => "success", 'message' => "บันทึกช่องการติดต่อเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            } else {
                $update = $this->db->prepare("UPDATE contact_config SET facebook = :facebook, line = :line, discord = :discord,  date = CURRENT_TIMESTAMP WHERE id = 1");
                try {
                    $update->execute([
                        ':facebook' => $facebook,
                        ':line' => $line,
                        ':discord' => $discord,
                    ]);
                    echo json_encode(array('status' => "success", 'message' => "บันทึกช่องการติดต่อเรียบร้อย"));
                } catch (Exception $e) {
                    echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
                }
            }
        }
    }

    public function add_stock_id($details, $id)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $string = preg_replace('~\R~u', "\n", $details);
            $exp_lines = explode("\n", $string);
            foreach ($exp_lines as $each_line) {
                $inseart = $this->db->prepare("INSERT INTO `stock_id` (`details`, `id_card`) VALUES (:details, :id_card);");
                $inseart->execute([':details' => $each_line, ':id_card' => $id]);
            }
            echo json_encode(array('status' => "success", 'message' => "เพิ่มสต็อกสินค้าแล้ว"));
        }
    }
    public function stock_id_id($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM stock_id WHERE id_card = :id_card AND username_buy = '0'");
        $stmt->execute([':id_card' => $id]);
        $result = $stmt->fetchAll();
        return $result;
    }
    public function sendToLineNotify($token, $message)
    {
        $lineNotifyUrl = 'https://notify-api.line.me/api/notify';
        $headers = array(
            'Content-Type: application/x-www-form-urlencoded',
            'Authorization: Bearer ' . $token,
        );
        $data = array('message' => $message);

        $options = array(
            'http' => array(
                'header' => implode("\r\n", $headers),
                'method' => 'POST',
                'content' => http_build_query($data),
            ),
        );

        $context = stream_context_create($options);
        $result = file_get_contents($lineNotifyUrl, false, $context);

        return $result;
    }
    public function edit_link_picture($id_picture, $edit_link_picture)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $insert = $this->db->prepare("UPDATE slide_picture SET link_picture = :edit_link_picture, date = CURRENT_TIMESTAMP WHERE id = :id_picture");
            try {
                $insert->execute([':id_picture' => $id_picture, ':edit_link_picture' => $edit_link_picture]);
                echo json_encode(array('status' => "success", 'message' => "อัพเดทรูปภาพเรียบร้อย"));
            } catch (Exception $e) {
                echo json_encode(array('status' => "error", 'message' => $e->getMessage()));
            }
        }
    }

    public function sendToDiscordWebhook($webhookUrl, $embedData)
    {
        $data = array('embeds' => $embedData);

        $options = array(
            'http' => array(
                'header' => "Content-type: application/json\r\n",
                'method' => 'POST',
                'content' => json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($webhookUrl, false, $context);
        return $result;
    }
    public function del_link_picture($id_picture)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $del_link_picture = $this->db->prepare("DELETE FROM `slide_picture` WHERE id = :id");
            $del_link_picture->execute([':id' => $id_picture]);
            echo json_encode(array('status' => "success", 'message' => "รูปภาพถูกลบออกจากระบบแล้ว"));
        }
    }
    public function del_users($id_users)
    {
        $resultuser = $this->resultuser();
        if ($resultuser['rank'] != "1") {
            echo json_encode(array('status' => "error", 'message' => "คุณไม่ได้เป็นแอดมินดูแลระบบ"));
        } else {
            $del_link_picture = $this->db->prepare("DELETE FROM `users` WHERE id = :id");
            $del_link_picture->execute([':id' => $id_users]);
            echo json_encode(array('status' => "success", 'message' => "ลบผู้ใช้งานออกจากระบบเรียบร้อย"));
        }
    }
    public function resultuser()
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute([':id' => $_SESSION['id']]);
        $result = $stmt->fetch();
        return $result;
    }
}
