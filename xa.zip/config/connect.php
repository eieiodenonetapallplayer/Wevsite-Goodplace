<?php
session_start();
error_reporting(0);

function database()
{
    $servername = "localhost";
    $db = "websitesellapp";
    $username = "root";
    $password = "";

    try {
        $stmt = new PDO("mysql:host=$servername;dbname=$db;charset=utf8;", $username, $password);
        $stmt->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $stmt;
    } catch (Exception $e) {
        echo $e->getMessage();
    }

    
}

function dd_q($str, $arr = [])
{
    $conn = database();
    try {
        $exec = $conn->prepare($str);
        $exec->execute($arr);
    } catch (PDOException $e) {
        return false;
    }
    return $exec;
}

$get_accktx = dd_q("SELECT * FROM acckt");
$accktx = $get_accktx->fetch(PDO::FETCH_ASSOC);

$get_notify = dd_q("SELECT * FROM notify_config WHERE id = 1");
$notify = $get_notify->fetch(PDO::FETCH_ASSOC);
