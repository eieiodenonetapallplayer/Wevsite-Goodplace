﻿$("#submit_login").click(function () {
    var username = $("#username").val();
    var password = $("#password").val();

    var waitingAlert = Swal.fire({
        icon: 'warning',
        title: 'โปรดรอสักครู่',
        text: "ระบบกำลังดำเนินการ โปรดห้ามรีเฟรช",
        showConfirmButton: false,
    });
    $.ajax({
        type: "POST",
        url: "../systems/login.php",
        dataType: "json",
        data: { username, password }, 
        success: function (data) {
            waitingAlert.close();
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.href = '/home';
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})
