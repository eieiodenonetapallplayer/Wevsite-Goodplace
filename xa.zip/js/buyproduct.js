$(".buyproduct-btn").click(function () {
    var productId = $(this).data("product-id");
    var productName = $(this).data("product-name");
    var productPrice = $(this).data("product-price");

    // แสดงค่าใน console.log
    // console.log("Product ID: " + productId);
    // console.log("Product Name: " + productName);
    // console.log("Product Price: " + productPrice);

    Swal.fire({
        icon: 'warning',
        text: '\n ซื้อสินค้า ' + productName + ' ' + productPrice + ' บาท',
        confirmButtonColor: '#30D65A',
        confirmButtonText: 'ยืนยัน',
        showCancelButton: true,
        cancelButtonColor: '#d33',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "../systems/buyproduct.php",
                dataType: "json",
                data: { productId, productPrice }, // ส่งข้อมูล productId และ productPrice ไปในรูปแบบ JSON
                success: function (data) {
                    if (data.status == "success") {
                        Swal.fire({
                            icon: 'success',
                            text: data.message,
                        }).then(function () {
                            window.location.href = '/history_buyproduct';
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            text: data.message,
                        }).then(function () {
                            // window.location.reload();
                            window.location.href = '/topup';
                        })
                    }
                }
            })
        }
    });
});
