$(".logout").click(function(){
    Swal.fire({
        text: "คุณต้องการออกจากระบบใช่หรือไม่",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ยืนยัน',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
        $.ajax({
            type:"POST",
            url:"../systems/logout.php",
            success:function(){
                Swal.fire({
                    icon: 'success',
                    text: 'ออกจากระบบเรียบร้อยแล้ว',
                }).then(function(){
                    window.location.href = '/';
                })
            }
            })
        }
    })
})