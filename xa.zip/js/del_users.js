$(".del_users").click(function () {
    var id_users = $(this).attr("id_users");
    var type = "del_users";
    Swal.fire({
        text: "ยืนยันการลบ ID : " + id_users,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#00e64d',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ยืนยัน',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "../systems/del_users.php",
                dataType: "json",
                data: { id_users, type }, // ส่งค่า id_picture และ type ไปยังเซิร์ฟเวอร์
                success: function (data) {
                    if (data.status == "success") {
                        Swal.fire({
                            icon: 'success',
                            text: data.message,
                        }).then(function () {
                            window.location.reload();
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            text: data.message,
                        })
                    }
                }
            })
        }
    })
})
