$("#submit_webconfig").click(function () {
    var name = $("#name").val();
    var logo_icon = $("#logo_icon").val();
    var logo = $("#logo").val();
    var description = $("#description").val();
    var keywords = $("#keywords").val();
    var background = $("#background").val();

    var main_color = $("#main_color").val();
    var sec_color = $("#sec_color").val();
    var font_color = $("#font_color").val();
    $.ajax({
        type: "POST",
        url: "../systems/webconfig.php",
        dataType: "json",
        data: { name, logo_icon, logo, background, description, keywords, main_color, sec_color, font_color },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})