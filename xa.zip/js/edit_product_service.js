$("#submit_edit_service").click(function () {
    var edit_id = $("#edit_id").val();
    var edit_idapi = $("#edit_idapi").val();
    var edit_name = $("#edit_name").val();
    var edit_desss = $("#edit_desss").val();
    var edit_price = $("#edit_price").val();
    $.ajax({
        type: "POST",
        url: "../systems/edit_product_service.php",
        dataType: "json",
        data: { edit_id, edit_idapi, edit_name, edit_desss, edit_price},
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})