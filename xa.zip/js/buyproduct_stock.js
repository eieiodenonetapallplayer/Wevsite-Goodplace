$(".submit_buyproduct").click(function () {
    var id_card = $(this).attr("data-product-id");
    var name_product = $(this).attr("data-product-name");
    var price_product = $(this).attr("data-product-price");
    Swal.fire({
        icon: 'warning',
        text: '\n ซื้อสินค้า ' + name_product + ' ' + price_product + ' บาท',
        confirmButtonColor: '#30D65A',
        confirmButtonText: 'ยืนยัน',
        showCancelButton: true,
        cancelButtonColor: '#d33',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "../../systems/buyproduct_stock.php",
                dataType: "json",
                data: { id_card },
                success: function (data) {
                    if (data.status == "success") {
                        Swal.fire({
                            icon: 'success',
                            text: data.message,
                        }).then(function () {
                            window.location.href = '/history_buyproduct';
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            text: data.message,
                        }).then(function () {
                            window.location.href = '/topup';
                        })
                    }
                }
            })
        }
    })
});