$("#submit_topupconfig").click(function () {
    /////// setting_wallet
    var wallet_phone = $("#wallet_phone").val();
    var wallet_fee = $("#wallet_fee").val();
    /////// setting bank
    var name_account = $("#name_account").val();
    var name_bank = $("#name_bank").val();
    var number_bank = $("#number_bank").val();

    var client_id = $("#client_id").val();
    var client_secret = $("#client_secret").val();
    var client_account = $("#client_account").val();

    $.ajax({
        type: "POST",
        url: "../systems/topup_config.php",
        dataType: "json",
        data: { wallet_phone, wallet_fee, name_account, name_bank, number_bank, client_id, client_secret, client_account },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})