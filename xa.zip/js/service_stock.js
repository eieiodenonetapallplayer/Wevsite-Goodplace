$("#submit_add_service").click(function () {
    var idapi = $("#idapi").val();
    var name = $("#name").val();
    var des = $("#des").val();
    var price = $("#price").val();
    $.ajax({
        type: "POST",
        url: "../systems/service_stock.php",
        dataType: "json",
        data: { idapi, name, des, price },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})