$("#edit_users").click(function () {
    var id = $("#edit-id").val();
    var password = $("#edit-password").val();
    var email = $("#edit-email").val();
    var point = $("#edit-point").val();
    var rank = $("#edit-rank").val();
    $.ajax({
        type: "POST",
        url: "../systems/edit_users.php",
        dataType: "json",
        data: { id, password, email, point, rank },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                });
            }
        }
    })
})
