$("#edit_freefire").click(function () {
    var edit_id = $("#edit_id").val();
    var edit_name = $("#edit_name").val();
    var edit_diamond = $("#edit_diamond").val();
    var edit_amount = $("#edit_amount").val();
    var edit_number = $("#edit_number").val();
    var edit_status = $("#edit_status").val();
    $.ajax({
        type: "POST",
        url: "../systems/topupgame/edit_freefire.php",
        dataType: "json",
        data: { edit_id, edit_name, edit_diamond, edit_amount, edit_number, edit_status },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                });
            }
        }
    })
})