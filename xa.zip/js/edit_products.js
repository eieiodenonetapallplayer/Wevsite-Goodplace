$("#edit_product").click(function () {
    var product_code = $("#product_code").val();
    var product_price = $("#product_price").val();
    var product_image = $("#product_image").val();
    var product_sell = $("#product_sell").val();
    var product_status = $("#product_status").val();
    $.ajax({
        type: "POST",
        url: "../systems/edit_products.php",
        dataType: "json",
        data: { product_code, product_price, product_image, product_sell, product_status },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                });
            }
        }
    })
})
