$("#submit_edit_product").click(function () {
    var id_product = $("#id_product").val();
    var edit_name_product = $("#edit_name_product").val();
    var edit_price_product = $("#edit_price_product").val();
    var edit_details_product = $("#edit_details_product").val();
    var edit_image_product = $("#edit_image_product").val();
    var edit_category_product = $("#edit_category_product").val();

    $.ajax({
        type: "POST",
        url: "../systems/edit_product_stock.php",
        dataType: "json",
        data: { id_product, edit_name_product, edit_price_product, edit_details_product, edit_image_product, edit_category_product},
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})