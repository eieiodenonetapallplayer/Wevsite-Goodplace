$("#submit_wallet").click(function () {
    var link_wallet = $("#link_wallet").val();

    var waitingAlert = Swal.fire({
        icon: 'warning',
        title: 'โปรดรอสักครู่',
        text: "ระบบกำลังดำเนินการ โปรดห้ามรีเฟรช",
        showConfirmButton: false,
    });

    $.ajax({
        type: "POST",
        url: "../systems/truewallet.php",
        dataType: "json",
        data: { link_wallet },
        success: function (data) {
            // ปิดกล่องข้อความ "โปรดรอสักครู่"
            waitingAlert.close();

            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})