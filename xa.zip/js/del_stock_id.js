$(".del_stock_id").click(function () {
    var id_picture = $(this).attr("id_stock");
    Swal.fire({
        text: "คุณแน่ใจที่ต้องการลบสินค้าที่ " + id_picture,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่',
        cancelButtonText: 'ไม่'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "../../systems/del_stock_id.php",
                dataType: "json",
                data: { id_picture },
                success: function (data) {
                    if (data.status == "success") {
                        Swal.fire({
                            icon: 'success',
                            text: data.message,
                        }).then(function () {
                            window.location.reload();
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            text: data.message,
                        })
                    }
                }
            })
        }
    })
})