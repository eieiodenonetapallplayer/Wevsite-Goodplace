$(".del_picture").click(function () {
    var id_picture = $(this).attr("id_picture");
    var type = "del_picture";
    Swal.fire({
        text: "ยืนยันการลบภาพ ID : " + id_picture,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#00e64d',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ยืนยัน',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: "POST",
                url: "../systems/del_link_picture.php",
                dataType: "json",
                data: { id_picture, type }, // ส่งค่า id_picture และ type ไปยังเซิร์ฟเวอร์
                success: function (data) {
                    if (data.status == "success") {
                        Swal.fire({
                            icon: 'success',
                            text: data.message,
                        }).then(function () {
                            window.location.reload();
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            text: data.message,
                        })
                    }
                }
            })
        }
    })
})
