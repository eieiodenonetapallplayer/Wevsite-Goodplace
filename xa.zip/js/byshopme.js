$("#submit_webconfig").click(function () {
    var username_byshopme = $("#username-byshopme").val();
    var apikey_byshopme = $("#apikey-byshopme").val();
    $.ajax({
        type: "POST",
        url: "../systems/byshopme.php",
        dataType: "json",
        data: { username_byshopme, apikey_byshopme },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})