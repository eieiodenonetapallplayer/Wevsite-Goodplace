$("#submit_verifyslip").click(async function () {
    // กำหนดฟังก์ชั่น File2Base64
    function File2Base64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = (error) => reject(error);
        });
    }
    async function imageDataFromSource(source) {
        const image = Object.assign(new Image(), {
            src: source
        });
        await new Promise((resolve) => image.addEventListener('load', () => resolve()));
        const context = Object.assign(document.createElement('canvas'), {
            width: image.width,
            height: image.height,
        }).getContext('2d');
        context.imageSmoothingEnabled = false;
        context.drawImage(image, 0, 0);
        return context.getImageData(0, 0, image.width, image.height);
    }
    // แปลงไฟล์รูปภาพเป็น base64
    var slipverifyBase64 = await File2Base64(slipInput.files[0]);

    // สร้าง QR Code จากข้อมูล slipverify
    const slipverifyImageData = await imageDataFromSource(slipverifyBase64);
    const slipverifyQRCode = jsQR(slipverifyImageData.data, slipverifyImageData.width, slipverifyImageData.height);

    // แจ้งเตือน "โปรดรอสักครู่"
    var waitingAlert = Swal.fire({
        icon: 'warning',
        title: 'โปรดรอสักครู่ ห้ามรีโหลดหน้าเว็บ',
        text: "ระบบกำลังดำเนินการ ไม่เกิน 3 นาที หากเกินติดต่อแอดมิน",
        showConfirmButton: false,
    });

    var slipverify = slipverifyQRCode.data
    console.log(slipverify);
    // ทำการส่งข้อมูลไปยัง API
    $.ajax({
        type: "POST",
        url: "../../systems/verifyslip.php",
        dataType: "json",
        data: {
            slipverify
        },
        success: function (data) {
            waitingAlert.close();
            // แสดงผลลัพธ์
            if (data.status == "success") {
                Swal.fire({
                    icon: "success",
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                });
            } else {
                Swal.fire({
                    icon: "error",
                    text: data.message,
                });
            }
        },
    });
});
