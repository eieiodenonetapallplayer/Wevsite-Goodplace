$("#submit_notify").click(function () {
    var dis_registered = $("#dis_registered").val();
    var dis_login = $("#dis_login").val();
    var dis_topup = $("#dis_topup").val();
    var dis_buy = $("#dis_buy").val();
    var dis_system = $("#dis_system").val();

    var line_registered = $("#line_registered").val();
    var line_login = $("#line_login").val();
    var line_topup = $("#line_topup").val();
    var line_buy = $("#line_buy").val();
    var line_system = $("#line_system").val();
    
    $.ajax({
        type: "POST",
        url: "../systems/notify.php",
        dataType: "json",
        data: { dis_registered, dis_login, dis_topup, dis_buy, dis_system, line_registered, line_login, line_topup, line_buy, line_system },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})