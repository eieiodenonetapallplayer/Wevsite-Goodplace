$("#submit_edit_link_picture").click(function () {
    var id_picture = $("#edit_picture_id").val();
    var edit_link_picture = $("#edit_link_picture").val();
    $.ajax({
        type: "POST",
        url: "../systems/edit_link_picture.php",
        dataType: "json",
        data: { id_picture, edit_link_picture },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})
