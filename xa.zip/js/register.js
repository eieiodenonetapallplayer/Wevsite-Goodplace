$("#submit_register").click(function () {
    var username = $("#username").val();
    var email = $("#email").val();
    var password = $("#password").val();
    var password_confirm = $("#password_confirm").val();

    var waitingAlert = Swal.fire({
        icon: 'warning',
        title: 'โปรดรอสักครู่',
        text: "ระบบกำลังดำเนินการ โปรดห้ามรีเฟรช",
        showConfirmButton: false,
    });

    $.ajax({
        type: "POST",
        url: "../systems/register.php",
        dataType: "json",
        data: { username, email, password, password_confirm },
        success: function (data) {
            waitingAlert.close();
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.href = '/home';
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                });
            }
        }
    })
})
