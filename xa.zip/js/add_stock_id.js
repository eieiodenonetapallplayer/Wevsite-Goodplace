$(document).ready(function () {
    var items = $('#stock');
    $('#add_details_stock_id').keydown(function (e) {
        newLines = $(this).val().split("\n").length;
        items.text(newLines);
    });
});
$("#submit_add_stock_id").click(function () {
    var details = $("#add_details_stock_id").val();
    var id_product = $(this).attr("id_product");
    $.ajax({
        type: "POST",
        url: "../../systems/add_stock_id.php",
        dataType: "json",
        data: { details, id_product },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})