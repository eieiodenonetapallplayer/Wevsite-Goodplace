$("#submit_password").click(function () {
    var password_old = $("#password_old").val();
    var password_new = $("#password_new").val();
    var password_new_confirm = $("#password_new_confirm").val();
    $.ajax({
        type: "POST",
        url: "../systems/password.php",
        dataType: "json",
        data: { password_old, password_new, password_new_confirm },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})