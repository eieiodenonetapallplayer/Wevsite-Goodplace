$("#submit_add_product").click(function () {
    var name_product = $("#name_product").val();
    var price_product = $("#price_product").val();
    var details_product = $("#details_product").val();
    var image_product = $("#picture_product").val();
    $.ajax({
        type: "POST",
        url: "../systems/product_stock.php",
        dataType: "json",
        data: { name_product, price_product, details_product, image_product },
        success: function (data) {
            if (data.status == "success") {
                Swal.fire({
                    icon: 'success',
                    text: data.message,
                }).then(function () {
                    window.location.reload();
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    text: data.message,
                })
            }
        }
    })
})